// FitBase service worker: يخلي التطبيق قابل للتثبيت ويسرّع التحميل.
// ما يخزّن طلبات Firebase/Firestore أبداً، فالبيانات تبقى حيّة دائماً.
const CACHE = 'fitbase-v1';
const SHELL = ['/', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (/googleapis\.com$|firebaseio\.com$|gstatic\.com$/.test(url.hostname) && !/fonts\./.test(url.hostname)) return;
  if (url.pathname.startsWith('/__/')) return;

  // الصفحة: الشبكة أولاً، وإذا ما أكو نت نرجع النسخة المخزنة
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).catch(() => caches.match('/')));
    return;
  }
  // باقي الملفات (JS/CSS/خطوط/صور): من الكاش وتتحدث بالخلفية
  e.respondWith(
    caches.match(req).then((hit) => {
      const net = fetch(req).then((res) => {
        if (res && (res.ok || res.type === 'opaque')) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      }).catch(() => hit);
      return hit || net;
    })
  );
});
