import React, { useEffect, useState } from 'react';

const isStandalone = () =>
  window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
const isIOS = () =>
  /iphone|ipad|ipod/i.test(navigator.userAgent) ||
  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

export default function InstallPrompt() {
  const [deferred, setDeferred] = useState(null);
  const [show, setShow] = useState(false);
  const [iosHelp, setIosHelp] = useState(false);

  useEffect(() => {
    try { if (localStorage.getItem('fitbase-install-dismissed') === '1') return; } catch {}
    if (isStandalone()) return;
    const onPrompt = (e) => { e.preventDefault(); setDeferred(e); setShow(true); };
    const onInstalled = () => { setShow(false); setDeferred(null); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    if (isIOS()) setShow(true);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  const dismiss = () => {
    setShow(false);
    try { localStorage.setItem('fitbase-install-dismissed', '1'); } catch {}
  };

  const install = async () => {
    if (deferred) {
      deferred.prompt();
      await deferred.userChoice;
      setDeferred(null);
      setShow(false);
    } else if (isIOS()) {
      setIosHelp(true);
    }
  };

  if (!show) return null;

  return (
    <div dir="rtl" style={{
      position: 'fixed', left: 12, right: 12, bottom: 12, zIndex: 9999,
      background: '#0a0f18', border: '1px solid #152033', borderRadius: 16,
      padding: 14, color: '#e2e8f0', boxShadow: '0 10px 40px rgba(0,0,0,.6)',
      maxWidth: 440, margin: '0 auto', fontFamily: 'Cairo, sans-serif',
    }}>
      {iosHelp ? (
        <div style={{ fontSize: 14, lineHeight: 1.9 }}>
          <b style={{ color: '#10b981' }}>التثبيت على الآيفون:</b>
          <ol style={{ margin: '6px 18px 10px', padding: 0 }}>
            <li>افتح الموقع من متصفح <b>Safari</b></li>
            <li>اضغط زر المشاركة <b>⬆︎</b> بأسفل الشاشة</li>
            <li>اختر <b>إضافة إلى الشاشة الرئيسية</b></li>
          </ol>
          <button onClick={dismiss} style={btn('#152033', '#e2e8f0')}>تمام</button>
        </div>
      ) : (
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <img src="/icons/icon-192.png" alt="" width="44" height="44" style={{ borderRadius: 10 }} />
          <div style={{ flex: 1, fontSize: 14, fontWeight: 700 }}>ثبّت FitBase كتطبيق على جهازك</div>
          <button onClick={install} style={btn('#10b981', '#02050a')}>تثبيت</button>
          <button onClick={dismiss} aria-label="إغلاق" style={{ ...btn('transparent', '#475569'), padding: '6px 8px' }}>✕</button>
        </div>
      )}
    </div>
  );
}

const btn = (bg, color) => ({
  background: bg, color, border: 'none', borderRadius: 10, padding: '8px 16px',
  fontWeight: 800, fontSize: 14, cursor: 'pointer', fontFamily: 'inherit',
});
