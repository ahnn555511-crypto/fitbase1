import React, { useState, useEffect, useRef } from 'react';
import { 
  Activity, Users, Radio, Settings, ShieldAlert, CreditCard, 
  Play, Dumbbell, MapPin, Smartphone, TrendingUp, Calendar, 
  MessageSquare, ShoppingCart, Bell, LogOut, ChevronRight, Zap, Loader2,
  Phone, KeyRound, CheckCircle2, UserPlus, Building, Plus, Trash2, Search,
  Image as ImageIcon, FileText, Send, Music, Target, Award, ShoppingBag,
  MonitorSmartphone, PackageOpen, Flame, Hash, UserCog, Megaphone, Settings2,
  Lock, Edit3, X, History, LifeBuoy, Clock, ArrowLeft, Headphones,
  QrCode, Droplets, Timer, Receipt, Dumbbell as DumbbellIcon
} from 'lucide-react';

import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, addDoc, onSnapshot, deleteDoc, doc, setDoc, getDoc, updateDoc, getDocs } from 'firebase/firestore';

const appId = 'fitbase-titanium-erp-v3';
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};
const customToken = null;

let app, auth, db;
try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
} catch (error) {
  console.error("Firebase init error:", error);
}

const theme = {
  bgMain: 'bg-[#02050a]', bgCard: 'bg-[#0a0f18]', border: 'border-[#152033]',
  emerald: 'text-[#10b981]', blue: 'text-[#3b82f6]', purple: 'text-[#8b5cf6]',
  gold: 'text-[#fbbf24]', bgEmerald: 'bg-[#10b981]', textMuted: 'text-[#475569]', inputBg: 'bg-[#020408]',
};

const setupEnvironment = () => {
  if (!document.getElementById('cairo-font')) {
    const link = document.createElement('link'); link.id = 'cairo-font';
    link.href = 'https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap'; link.rel = 'stylesheet'; document.head.appendChild(link);
    const style = document.createElement('style');
    style.innerHTML = `
      * { font-family: 'Cairo', sans-serif; }
      .custom-scrollbar::-webkit-scrollbar { width: 6px; }
      .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
      .custom-scrollbar::-webkit-scrollbar-thumb { background: #152033; border-radius: 10px; }
      .hide-scrollbar::-webkit-scrollbar { display: none; }
      @keyframes fade-in { from { opacity: 0; transform: translateY(15px); } to { opacity: 1; transform: translateY(0); } }
      .animate-fade-in { animation: fade-in 0.3s ease-out forwards; }
    `;
    document.head.appendChild(style);
  }
};

const fileToBase64 = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader(); reader.readAsDataURL(file); reader.onload = () => resolve(reader.result); reader.onerror = error => reject(error);
});

export default function App() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [view, setView] = useState('loading');
  const [toast, setToast] = useState(null);

  const showToast = (msg, type = 'success') => { setToast({ msg, type }); setTimeout(() => setToast(null), 4000); };

  const logAudit = async (action, details) => {
     if(!profile) return;
     try {
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'audit_logs'), {
           userId: profile.id, userName: profile.name, role: profile.role, action, details, timestamp: new Date().toISOString()
        });
     } catch(e){}
  };

  useEffect(() => {
    setupEnvironment();
    const authenticate = async () => {
      try { if (customToken) await signInWithCustomToken(auth, customToken); else await signInAnonymously(auth); } catch (err) { setAuthLoading(false); }
    };
    authenticate();
    const unsub = onAuthStateChanged(auth, async (currentUser) => { setUser(currentUser); setView('auth'); setAuthLoading(false); });
    return () => unsub();
  }, []);

  const logout = () => { setProfile(null); setView('auth'); };

  if (authLoading || view === 'loading') {
    return (
      <div className={`min-h-screen ${theme.bgMain} flex flex-col items-center justify-center`} dir="rtl">
        <Activity className={`${theme.emerald} w-24 h-24 mb-6 animate-pulse drop-shadow-[0_0_20px_rgba(16,185,129,0.5)]`} />
        <h1 className="text-white text-5xl font-black tracking-widest uppercase">FitBase <span className="text-blue-500">ERP</span></h1>
        <Loader2 className="w-8 h-8 text-slate-500 animate-spin mt-8" />
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${theme.bgMain} text-slate-200 overflow-hidden selection:bg-blue-500/30`} dir="rtl">
      {toast && (
        <div className={`fixed top-6 left-1/2 -translate-x-1/2 z-[9999] px-6 py-4 rounded-2xl font-bold shadow-[0_20px_50px_rgba(0,0,0,0.5)] transition-all animate-fade-in flex items-center gap-3 border ${toast.type === 'error' ? 'bg-red-950/95 text-red-400 border-red-500/50' : 'bg-emerald-950/95 text-emerald-400 border-emerald-500/50 backdrop-blur-xl'}`}>
          {toast.type === 'success' ? <CheckCircle2 size={24}/> : toast.type === 'info' ? <Bell size={24} className="text-blue-400"/> : <ShieldAlert size={24}/>}
          {toast.msg}
        </div>
      )}
      
      {view === 'auth' && <AuthFlow user={user} setProfile={setProfile} setView={setView} showToast={showToast} logAudit={logAudit} />}
      {view === 'super_admin' && <SuperAdmin logout={logout} profile={profile} theme={theme} showToast={showToast} setProfile={setProfile} logAudit={logAudit} />}
      {view === 'gym_admin' && <GymAdmin profile={profile} logout={logout} theme={theme} showToast={showToast} logAudit={logAudit} />}
      {view === 'user' && <UserApp profile={profile} user={user} logout={logout} theme={theme} showToast={showToast} logAudit={logAudit} />}
    </div>
  );
}

function AuthFlow({ user, setProfile, setView, showToast, logAudit }) {
  const [step, setStep] = useState(1);
  const [phone, setPhone] = useState('');
  const [passcode, setPasscode] = useState('');
  
  const [name, setName] = useState('');
  const [role, setRole] = useState('user');
  const [selectedGym, setSelectedGym] = useState('');
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');
  const [gyms, setGyms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [foundProfile, setFoundProfile] = useState(null);

  useEffect(() => {
    if(!user) return;
    const unsub = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'gyms'), (snap) => {
      let g = []; snap.forEach(d => { if(d.data().status !== 'suspended') g.push({ id: d.id, ...d.data() }) }); setGyms(g);
    });
    const setupSuperAdmin = async () => {
      try {
         const saRef = doc(db, 'artifacts', appId, 'public', 'data', 'profiles', 'master_admin');
         const saSnap = await getDoc(saRef);
         if(!saSnap.exists()) {
            await setDoc(saRef, { name: 'المدير العام', phone: '0000', passcode: '0000', role: 'super_admin', gymId: 'system', status: 'active', staffRole: 'owner' });
         }
      } catch(e) {}
    };
    setupSuperAdmin();
    return () => unsub();
  }, [user]);

  const handlePhoneSubmit = async (e) => {
    e.preventDefault();
    if (phone.trim().length < 4) return showToast('رقم هاتف غير صالح', 'error');
    setLoading(true);
    try {
      const profilesSnap = await getDocs(collection(db, 'artifacts', appId, 'public', 'data', 'profiles'));
      let match = null;
      profilesSnap.forEach(d => { if(d.data().phone === phone.trim()) match = { id: d.id, ...d.data() }; });

      if(match) {
         if(match.status === 'suspended') showToast('الحساب موقوف من قبل الإدارة', 'error');
         else { setFoundProfile(match); setStep(2); }
      } else {
         const reqsSnap = await getDocs(collection(db, 'artifacts', appId, 'public', 'data', 'join_requests'));
         let isPending = false;
         reqsSnap.forEach(r => { if(r.data().phone === phone.trim() && r.data().status === 'pending') isPending = true; });
         if(isPending) setStep(4); else setStep(3); 
      }
    } catch (err) { showToast('خطأ بالاتصال', 'error'); }
    setLoading(false);
  };

  const handlePasscodeSubmit = (e) => {
    e.preventDefault();
    if(passcode === foundProfile.passcode) {
      setProfile(foundProfile); setView(foundProfile.role); showToast(`تم الدخول بنجاح`);
    } else showToast('الرمز السري خطأ', 'error');
  };

  const handleRequestAccess = async (e) => {
    e.preventDefault();
    if (!name || !selectedGym) return showToast('اكمل الحقول المطلوبة', 'error');
    setLoading(true);
    const gymName = gyms.find(g => g.id === selectedGym)?.name || '';
    try {
      await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'join_requests'), {
        phone: phone.trim(), name, role, gymId: selectedGym, gymName,
        age: age||'', weight: weight||'', height: height||'', status: 'pending', createdAt: new Date().toISOString()
      });
      setStep(4); showToast('تم إرسال الطلب');
    } catch (err) { showToast('حدث خطأ', 'error'); }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80')] bg-cover bg-center">
      <div className="absolute inset-0 bg-[#02050a]/95 backdrop-blur-md"></div>
      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-28 h-28 rounded-full bg-[#0a0f18] border-2 border-blue-500 mb-4 shadow-[0_0_50px_rgba(59,130,246,0.3)]">
            <Activity size={56} className="text-blue-400" />
          </div>
          <h1 className="text-5xl font-black text-white tracking-widest uppercase">Fit<span className="text-blue-500">Base</span></h1>
        </div>

        <div className={`${theme.bgCard} border border-[#152033] p-8 rounded-[2rem] shadow-2xl relative overflow-hidden backdrop-blur-xl`}>
          {step === 1 && (
            <form onSubmit={handlePhoneSubmit} className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-bold text-white text-center">دخول النظام</h2>
              <div className="relative">
                <Phone className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                <input type="tel" value={phone} onChange={e=>setPhone(e.target.value)} placeholder="رقم الهاتف (المدير: 0000)" required dir="ltr" className={`w-full ${theme.inputBg} border ${theme.border} rounded-2xl py-4 pr-12 pl-4 text-white focus:border-blue-500 outline-none text-left font-sans text-xl`} />
              </div>
              <button disabled={loading} className={`w-full bg-blue-600 hover:bg-blue-500 text-white font-black text-lg py-4 rounded-2xl transition flex justify-center items-center gap-2 active:scale-95 shadow-lg shadow-blue-500/20`}>
                {loading ? <Loader2 className="animate-spin" /> : <><ChevronRight size={20} /> متابعة</>}
              </button>
            </form>
          )}

          {step === 2 && (
            <form onSubmit={handlePasscodeSubmit} className="space-y-6 animate-fade-in">
              <div className="text-center mb-6">
                 <h2 className="text-2xl font-bold text-white">الرمز السري</h2>
                 <p className="text-sm text-slate-400 mt-1">{foundProfile?.role === 'super_admin' ? 'الإدارة العليا' : foundProfile?.name}</p>
              </div>
              <div className="relative">
                <KeyRound className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                <input type="password" value={passcode} onChange={e=>setPasscode(e.target.value)} placeholder="****" required dir="ltr" className={`w-full ${theme.inputBg} border ${theme.border} rounded-2xl py-4 pr-12 pl-4 text-white focus:border-blue-500 outline-none text-center font-sans text-3xl tracking-[1em]`} />
              </div>
              <button className={`w-full bg-blue-600 hover:bg-blue-500 text-white font-black text-lg py-4 rounded-2xl transition flex justify-center items-center gap-2 shadow-lg shadow-blue-500/20`}><CheckCircle2 size={20}/> الدخول</button>
              <button type="button" onClick={()=>{setStep(1); setPasscode('');}} className="w-full text-slate-500 text-sm font-bold hover:text-white">رجوع</button>
            </form>
          )}

          {step === 3 && (
            <form onSubmit={handleRequestAccess} className="space-y-4 animate-fade-in max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
              <h2 className="text-xl font-bold text-white text-center mb-4">إنشاء ملف رياضي</h2>
              <input type="text" value={name} onChange={e=>setName(e.target.value)} placeholder="الاسم الكامل" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl py-3.5 px-4 outline-none text-white focus:border-blue-500`} />
              
              <div className="grid grid-cols-2 gap-3 mb-2">
                 <div onClick={()=>setRole('user')} className={`p-3 rounded-xl border text-center font-bold cursor-pointer transition ${role==='user'?'bg-blue-500/10 border-blue-500 text-blue-400 shadow-lg':'border-[#152033] text-slate-400 hover:bg-[#152033]'}`}>لاعب / متدرب</div>
                 <div onClick={()=>setRole('gym_admin')} className={`p-3 rounded-xl border text-center font-bold cursor-pointer transition ${role==='gym_admin'?'bg-emerald-500/10 border-emerald-500 text-emerald-400 shadow-lg':'border-[#152033] text-slate-400 hover:bg-[#152033]'}`}>مدير قاعة</div>
              </div>
              
              <select value={selectedGym} onChange={e=>setSelectedGym(e.target.value)} required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl py-3.5 px-4 outline-none text-white font-bold`}>
                <option value="" disabled>-- اختر القاعة الرياضية --</option>
                {gyms.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
              
              {role === 'user' && (
                <div className="grid grid-cols-3 gap-3">
                   <input type="number" value={age} onChange={e=>setAge(e.target.value)} placeholder="العمر" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl py-3 px-2 outline-none text-white text-center`} />
                   <input type="number" value={weight} onChange={e=>setWeight(e.target.value)} placeholder="الوزن" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl py-3 px-2 outline-none text-white text-center`} />
                   <input type="number" value={height} onChange={e=>setHeight(e.target.value)} placeholder="الطول" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl py-3 px-2 outline-none text-white text-center`} />
                </div>
              )}
              <button disabled={loading} className={`w-full bg-blue-600 text-white font-black py-4 rounded-xl mt-4 active:scale-95 shadow-lg shadow-blue-500/20`}>{loading ? <Loader2 className="animate-spin mx-auto"/> : 'إرسال طلب الانضمام'}</button>
              <button type="button" onClick={()=>setStep(1)} className="w-full text-slate-500 text-sm font-bold mt-2 hover:text-white">تراجع</button>
            </form>
          )}

          {step === 4 && (
            <div className="text-center animate-fade-in py-6">
               <CheckCircle2 size={64} className="text-yellow-500 mx-auto mb-4" />
               <h2 className="text-2xl font-bold text-white mb-2">طلبك قيد المراجعة</h2>
               <p className="text-slate-400 text-sm leading-relaxed px-4">تم إرسال بياناتك للإدارة بنجاح. يرجى الانتظار لحين الموافقة وتزويدك بالرمز السري الخاص بك.</p>
               <button onClick={()=>setStep(1)} className="text-blue-500 font-bold hover:underline mt-6">العودة للرئيسية</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SuperAdmin({ logout, profile, theme, showToast, setProfile, logAudit }) {
  const [activeTab, setActiveTab] = useState('overview'); 
  const [requests, setRequests] = useState([]);
  const [gyms, setGyms] = useState([]);
  const [allUsers, setAllUsers] = useState([]); 
  const [auditLogs, setAuditLogs] = useState([]);
  const [banners, setBanners] = useState([]);
  const [storeItems, setStoreItems] = useState([]);
  const [musicTracks, setMusicTracks] = useState([]);
  const [tickets, setTickets] = useState([]);
  
  const [editModal, setEditModal] = useState({ isOpen: false, type: '', data: null });
  const [gymForm, setGymForm] = useState({ name:'', location:'', owner:'', phone:'', email:'', duration:'30', tier:'Standard', amenities:'', capacity:'', logo:'' });
  
  const staffMembers = allUsers.filter(u => u.role === 'super_admin');
  const regularUsers = allUsers.filter(u => u.role === 'user' || u.role === 'gym_admin');

  useEffect(() => {
    const uGyms = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'gyms'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setGyms(arr); });
    const uReqs = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'join_requests'), s => { let arr=[]; s.forEach(d=>{if(d.data().status==='pending') arr.push({id:d.id,...d.data()})}); setRequests(arr); });
    const uUsers = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'profiles'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setAllUsers(arr); });
    const uLogs = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'audit_logs'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); arr.sort((a,b)=>new Date(b.timestamp)-new Date(a.timestamp)); setAuditLogs(arr); });
    const uBanners = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'banners'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setBanners(arr); });
    const uStore = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'store_items'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setStoreItems(arr); });
    const uMusic = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'music_tracks'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setMusicTracks(arr); });
    const uTickets = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'support_tickets'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setTickets(arr); });
    return () => { uGyms(); uReqs(); uUsers(); uLogs(); uBanners(); uStore(); uMusic(); uTickets(); };
  }, []);

  const openEditModal = (type, data) => setEditModal({ isOpen: true, type, data });
  const closeEditModal = () => setEditModal({ isOpen: false, type: '', data: null });

  const approveRequest = async (req, passcode) => {
    if(!passcode || passcode.length < 4) return showToast('يرجى تعيين رمز من 4 أرقام على الأقل', 'error');
    const checkinPin = Math.floor(1000 + Math.random() * 9000).toString();
    try {
      await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', req.id), {
        name: req.name, phone: req.phone, role: req.role, passcode, checkinPin, gymId: req.gymId, gymName: req.gymName, status: 'active', points: 0, waterIntake: 0, createdAt: new Date().toISOString(), subscriptionEndsAt: new Date(Date.now() + 30*24*60*60*1000).toISOString(), weight: req.weight||'', height: req.height||'', age: req.age||'', calories: '', dietPlan: ''
      });
      await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'join_requests', req.id), { status: 'approved' });
      logAudit('موافقة حساب', `تفعيل حساب ${req.name} (${req.role})`);
      showToast(`تم التفعيل بنجاح.`);
    } catch(e) { showToast('خطأ', 'error'); }
  };

  const handleUpdateProfile = async (e) => {
     e.preventDefault(); const fd = new FormData(e.target);
     const updates = { name: fd.get('name'), phone: fd.get('phone'), passcode: fd.get('passcode') };
     if(editModal.type === 'user') updates.gymId = fd.get('gymId');
     try {
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', editModal.data.id), updates);
        if(editModal.data.id === profile.id) setProfile({...profile, ...updates});
        logAudit('تعديل ملف', `تعديل بيانات ${editModal.data.name}`);
        closeEditModal(); showToast('تم الحفظ');
     } catch(e) {}
  };

  const handleAddGym = async (e) => {
     e.preventDefault();
     const subDate = new Date(); subDate.setDate(subDate.getDate() + parseInt(gymForm.duration));
     try {
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'gyms'), {
           ...gymForm, status: 'active', createdAt: new Date().toISOString(), subscriptionEndsAt: subDate.toISOString()
        });
        logAudit('إضافة قاعة', `تسجيل قاعة ${gymForm.name} في النظام`);
        setGymForm({ name:'', location:'', owner:'', phone:'', email:'', duration:'30', tier:'Standard', amenities:'', capacity:'', logo:'' });
        showToast('تمت إضافة القاعة بنجاح');
     } catch(e){}
  };

  const handleUpdateGym = async (e) => {
     e.preventDefault(); const fd = new FormData(e.target);
     try {
        await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'gyms', editModal.data.id), { name: fd.get('name'), location: fd.get('location'), owner: fd.get('owner'), phone: fd.get('phone') });
        logAudit('تعديل قاعة', `تعديل بيانات قاعة ${editModal.data.name}`);
        closeEditModal(); showToast('تم تحديث القاعة');
     } catch(e){}
  };

  const addStaff = async (e) => {
     e.preventDefault(); const fd = new FormData(e.target);
     try {
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'profiles'), { name: fd.get('name'), phone: fd.get('phone'), passcode: fd.get('passcode'), role: fd.get('role'), status: 'active', gymId: 'system' });
        logAudit('إضافة موظف', `إضافة ${fd.get('name')} بصلاحية ${fd.get('role')}`);
        e.target.reset(); showToast('تم إضافة الموظف');
     } catch(e){}
  };

  const MediaUploader = ({ type }) => {
    const [title, setTitle] = useState(''); const [fileUrl, setFileUrl] = useState(''); const [price, setPrice] = useState(''); const [loading, setLoading] = useState(false);
    const handleUpload = async (e) => {
       e.preventDefault(); const file = e.target.fileInput?.files[0]; let finalData = fileUrl;
       if (file) {
          if (file.size > 800000) return showToast('الملف كبير جداً. (استخدم رابط)', 'error');
          setLoading(true); try { finalData = await fileToBase64(file); } catch(e) { setLoading(false); return; }
       }
       if (!finalData) return showToast('اختر ملف أو رابط', 'error');
       try {
         if (type === 'banner') { await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'banners'), { title, url: finalData, createdAt: new Date().toISOString() }); logAudit('رفع بانر', title); }
         else if (type === 'music') { await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'music_tracks'), { title, url: finalData, createdAt: new Date().toISOString() }); logAudit('رفع موسيقى', title); }
         else if (type === 'store') { await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'store_items'), { title, price, url: finalData, createdAt: new Date().toISOString() }); logAudit('إضافة للمتجر', title); }
         setTitle(''); setFileUrl(''); setPrice(''); e.target.reset(); showToast('تمت الإضافة بنجاح');
       } catch(e) { showToast('خطأ بالرفع', 'error'); } setLoading(false);
    };
    return (
      <form onSubmit={handleUpload} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] shadow-xl mb-6 flex flex-col md:flex-row gap-4 items-end`}>
         <div className="flex-1 w-full"><label className="block text-sm font-bold text-slate-400 mb-2">العنوان / الاسم</label><input required value={title} onChange={e=>setTitle(e.target.value)} type="text" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>
         {type === 'store' && <div className="w-32"><label className="block text-sm font-bold text-slate-400 mb-2">السعر</label><input required value={price} onChange={e=>setPrice(e.target.value)} type="number" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>}
         <div className="flex-1 w-full"><label className="block text-sm font-bold text-slate-400 mb-2">رفع ملف (Max 800KB)</label><input name="fileInput" type="file" accept={type==='music'?'audio/*':'image/*'} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-2.5 text-slate-400 file:bg-blue-500/20 file:text-blue-400 file:rounded-lg file:border-0`} /></div>
         <div className="flex-1 w-full"><label className="block text-sm font-bold text-slate-400 mb-2">رابط (URL) بديل</label><input value={fileUrl} onChange={e=>setFileUrl(e.target.value)} type="text" dir="ltr" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>
         <button disabled={loading} className="bg-blue-600 text-white font-bold py-3.5 px-6 rounded-xl flex items-center justify-center gap-2">{loading?<Loader2 className="animate-spin"/>:'إضافة'}</button>
      </form>
    );
  };

  const deleteItem = async (col, id) => { try{ await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', col, id)); logAudit('حذف عنصر', `تم الحذف من ${col}`); showToast('تم الحذف'); }catch(e){} };

  return (
    <div className={`flex h-screen overflow-hidden ${theme.bgMain}`}>
      <div className={`w-72 ${theme.bgCard} border-l ${theme.border} flex flex-col z-20 shadow-2xl`}>
        <div className={`p-8 border-b ${theme.border}`}>
          <ShieldAlert size={40} className="text-blue-500 mb-4" />
          <h1 className="text-2xl font-black text-white leading-tight">النظام المؤسسي</h1>
          <p className="text-xs font-bold text-blue-400 bg-blue-500/10 px-2 py-1 rounded mt-2 inline-block">ERP Dashboard</p>
        </div>
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
          <SidebarBtn icon={<TrendingUp/>} label="الرئيسية" active={activeTab==='overview'} onClick={()=>setActiveTab('overview')} color="blue" />
          <SidebarBtn icon={<UserPlus/>} label="الطلبات" active={activeTab==='requests'} onClick={()=>setActiveTab('requests')} badge={requests.length} color="blue" />
          <SidebarBtn icon={<Building/>} label="إدارة القاعات" active={activeTab==='gyms'} onClick={()=>setActiveTab('gyms')} color="blue" />
          <SidebarBtn icon={<Users/>} label="المستخدمين" active={activeTab==='users'} onClick={()=>setActiveTab('users')} color="blue" />
          <SidebarBtn icon={<UserCog/>} label="الموظفين" active={activeTab==='staff'} onClick={()=>setActiveTab('staff')} color="emerald" />
          <div className="my-3 border-t border-[#152033] pt-3 flex flex-col gap-2">
            <SidebarBtn icon={<ImageIcon/>} label="البنرات" active={activeTab==='banners'} onClick={()=>setActiveTab('banners')} color="purple" />
            <SidebarBtn icon={<ShoppingBag/>} label="المتجر المركزي" active={activeTab==='store'} onClick={()=>setActiveTab('store')} color="purple" />
            <SidebarBtn icon={<Headphones/>} label="الموسيقى" active={activeTab==='music'} onClick={()=>setActiveTab('music')} color="purple" />
            <SidebarBtn icon={<LifeBuoy/>} label="تذاكر الدعم" active={activeTab==='tickets'} onClick={()=>setActiveTab('tickets')} badge={tickets.filter(t=>t.status==='open').length} color="gold" />
            <SidebarBtn icon={<History/>} label="سجل النظام" active={activeTab==='audit'} onClick={()=>setActiveTab('audit')} color="purple" />
          </div>
        </nav>
        <div className={`p-4 border-t ${theme.border}`}>
           <button onClick={logout} className="w-full text-slate-400 hover:text-red-400 bg-[#02050a] p-4 rounded-2xl font-bold flex justify-center items-center gap-2"><LogOut size={20}/> خروج</button>
        </div>
      </div>

      <div className="flex-1 p-8 overflow-y-auto custom-scrollbar relative bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#0a0f18] via-[#02050a] to-[#02050a]">
        
        {editModal.isOpen && (
          <div className="absolute inset-0 bg-[#02050a]/90 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in">
             <div className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2rem] w-full max-w-lg shadow-2xl`}>
                <div className="flex justify-between items-center mb-6">
                   <h3 className="text-2xl font-bold text-white flex items-center gap-2"><Edit3 className="text-blue-500"/> تعديل بيانات {editModal.type==='gym'?'القاعة':'الحساب'}</h3>
                   <button onClick={closeEditModal} className="text-slate-500 hover:text-white"><X size={24}/></button>
                </div>
                {editModal.type === 'gym' ? (
                  <form onSubmit={handleUpdateGym} className="space-y-4">
                     <input name="name" defaultValue={editModal.data.name} placeholder="اسم القاعة" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} />
                     <input name="location" defaultValue={editModal.data.location} placeholder="الموقع" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} />
                     <input name="owner" defaultValue={editModal.data.owner} placeholder="اسم المالك" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} />
                     <input name="phone" defaultValue={editModal.data.phone} placeholder="هاتف القاعة" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} />
                     <button className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl mt-4">حفظ التعديلات</button>
                  </form>
                ) : (
                  <form onSubmit={handleUpdateProfile} className="space-y-4">
                     <input name="name" defaultValue={editModal.data.name} placeholder="الاسم" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} />
                     <input name="phone" defaultValue={editModal.data.phone} placeholder="الهاتف" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} dir="ltr"/>
                     <input name="passcode" defaultValue={editModal.data.passcode} placeholder="الرمز السري" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none tracking-widest text-center`} dir="ltr"/>
                     {editModal.type === 'user' && (
                       <select name="gymId" defaultValue={editModal.data.gymId} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`}>
                         {gyms.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}
                       </select>
                     )}
                     <button className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl mt-4">تحديث الملف</button>
                  </form>
                )}
             </div>
          </div>
        )}

        {activeTab === 'overview' && (
          <div className="animate-fade-in max-w-6xl mx-auto">
            <h2 className="text-4xl font-black text-white mb-8">نظرة عامة</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
               <StatCard icon={<Building/>} title="إجمالي القاعات" value={gyms.length} color="emerald" />
               <StatCard icon={<Users/>} title="قاعدة اللاعبين" value={regularUsers.filter(u=>u.role==='user').length} color="blue" />
               <StatCard icon={<UserCog/>} title="مدراء القاعات" value={regularUsers.filter(u=>u.role==='gym_admin').length} color="purple" />
               <StatCard icon={<Activity/>} title="عمليات النظام" value={auditLogs.length} color="gold" />
            </div>
          </div>
        )}

        {activeTab === 'requests' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">الطلبات الجديدة</h2>
             <div className="space-y-4">
                {requests.length===0 && <div className={`p-10 text-center ${theme.bgCard} rounded-[2rem] border ${theme.border} text-slate-500 font-bold`}>لا يوجد طلبات.</div>}
                {requests.map(req => (
                  <div key={req.id} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] flex flex-col md:flex-row justify-between items-center shadow-lg gap-6`}>
                    <div className="flex gap-4 items-center flex-1">
                      <div className="w-14 h-14 bg-[#02050a] text-white rounded-2xl flex items-center justify-center font-black text-xl border border-[#152033]">{req.name.charAt(0)}</div>
                      <div>
                        <h3 className="text-xl font-bold text-white">{req.name}</h3>
                        <p className={`text-sm font-bold mt-1 ${req.role === 'gym_admin' ? 'text-blue-400' : 'text-emerald-400'}`}>{req.role === 'gym_admin' ? 'مدير قاعة' : 'لاعب'} • {req.gymName}</p>
                      </div>
                    </div>
                    <form onSubmit={e=>{e.preventDefault(); approveRequest(req, e.target.pin.value);}} className="flex items-center gap-3">
                       <input name="pin" required placeholder="تعيين رمز سرّي" className={`w-36 ${theme.inputBg} border ${theme.border} rounded-xl p-4 outline-none text-white text-center font-bold`} />
                       <button className="bg-blue-600 text-white px-6 py-4 rounded-xl font-bold flex items-center gap-2"><CheckCircle2 size={18}/> تفعيل</button>
                    </form>
                  </div>
                ))}
             </div>
          </div>
        )}

        {activeTab === 'gyms' && (
          <div className="animate-fade-in max-w-6xl mx-auto">
            <h2 className="text-3xl font-black text-white mb-6">إدارة القاعات الرياضية</h2>
            <form onSubmit={handleAddGym} className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2rem] mb-8 shadow-xl`}>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                 <div><label className="block text-xs font-bold text-slate-400 mb-2">اسم القاعة</label><input required value={gymForm.name} onChange={e=>setGymForm({...gymForm, name:e.target.value})} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>
                 <div><label className="block text-xs font-bold text-slate-400 mb-2">الموقع التفصيلي</label><input required value={gymForm.location} onChange={e=>setGymForm({...gymForm, location:e.target.value})} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>
                 <div><label className="block text-xs font-bold text-slate-400 mb-2">اسم المالك</label><input required value={gymForm.owner} onChange={e=>setGymForm({...gymForm, owner:e.target.value})} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>
                 <div><label className="block text-xs font-bold text-slate-400 mb-2">هاتف القاعة</label><input required value={gymForm.phone} onChange={e=>setGymForm({...gymForm, phone:e.target.value})} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>
                 <div><label className="block text-xs font-bold text-slate-400 mb-2">البريد الإلكتروني</label><input value={gymForm.email} onChange={e=>setGymForm({...gymForm, email:e.target.value})} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none`} /></div>
                 <div><label className="block text-xs font-bold text-slate-400 mb-2">مدة اشتراك القاعة</label>
                    <select value={gymForm.duration} onChange={e=>setGymForm({...gymForm, duration:e.target.value})} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3.5 text-white outline-none font-bold`}>
                       <option value="30">شهر واحد</option><option value="180">6 أشهر</option><option value="365">سنة كاملة</option>
                    </select>
                 </div>
               </div>
               <button type="submit" className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-4 rounded-xl flex justify-center items-center gap-2"><Plus size={20}/> إدراج القاعة</button>
            </form>

            <div className="grid grid-cols-2 gap-6">
               {gyms.map(g => {
                 const days = Math.ceil((new Date(g.subscriptionEndsAt) - new Date()) / (1000 * 60 * 60 * 24));
                 return (
                  <div key={g.id} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] flex flex-col justify-between shadow-lg`}>
                     <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-4">
                           <div className="w-14 h-14 bg-[#02050a] rounded-xl flex items-center justify-center border border-[#152033]"><Building className="text-blue-500" size={24}/></div>
                           <div><h4 className="font-bold text-white text-lg">{g.name}</h4><p className="text-xs text-slate-400">{g.location}</p></div>
                        </div>
                        <button onClick={()=>openEditModal('gym', g)} className="p-2 bg-[#02050a] text-slate-400 hover:text-blue-400 rounded-xl"><Edit3 size={18}/></button>
                     </div>
                     <div className="bg-[#02050a] p-4 rounded-xl border border-[#152033] flex justify-between items-center mb-4">
                        <span className="text-xs font-bold text-slate-400">اشتراك القاعة:</span>
                        <span className={`text-sm font-black ${days<=0?'text-red-500':'text-emerald-500'}`}>{days<=0?'منتهي':`باقي ${days} يوم`}</span>
                     </div>
                     <div className="flex gap-2">
                        <button onClick={async()=>{ await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'gyms', g.id), {status: g.status==='active'?'suspended':'active'}); logAudit('حالة قاعة', g.name); }} className={`flex-1 py-3 rounded-xl font-bold flex justify-center border ${g.status==='active'?'bg-[#02050a] text-red-400 border-red-500/30 hover:bg-red-500/10':'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'}`}>{g.status==='active'?'إيقاف القاعة':'تفعيل القاعة'}</button>
                     </div>
                  </div>
               )})}
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="animate-fade-in max-w-6xl mx-auto">
            <h2 className="text-3xl font-black text-white mb-6">قاعدة المستخدمين</h2>
            <div className={`${theme.bgCard} border ${theme.border} rounded-[2rem] overflow-hidden`}>
               <table className="w-full text-right">
                 <thead className="bg-[#02050a] text-slate-400 text-sm"><tr><th className="p-5">الاسم</th><th className="p-5">القاعة</th><th className="p-5">PIN</th><th className="p-5">الإجراءات</th></tr></thead>
                 <tbody>
                   {regularUsers.map(u => (
                     <tr key={u.id} className="border-t border-[#152033] hover:bg-[#152033]/30">
                       <td className="p-5"><div className="font-bold text-white flex items-center gap-2">{u.name} <span className={`text-[10px] px-2 rounded ${u.role==='gym_admin'?'bg-blue-500/20 text-blue-400':'bg-slate-800'}`}>{u.role==='gym_admin'?'مدير':'لاعب'}</span></div><div className="text-xs text-slate-500" dir="ltr">{u.phone}</div></td>
                       <td className="p-5 text-sm text-slate-300">{u.gymName}</td>
                       <td className="p-5 font-sans font-black text-emerald-400">{u.checkinPin}</td>
                       <td className="p-5 flex gap-2">
                         <button onClick={()=>openEditModal('user', u)} className="p-2 bg-[#02050a] text-blue-400 rounded-lg"><Edit3 size={16}/></button>
                         <button onClick={async()=>{ await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', u.id), {status: u.status==='suspended'?'active':'suspended'}); logAudit('حظر مستخدم', u.name); }} className={`p-2 rounded-lg border ${u.status==='suspended'?'bg-emerald-500/10 text-emerald-400':'bg-[#02050a] text-red-400 border-[#152033]'}`}>{u.status==='suspended'?'فك الحظر':'حظر'}</button>
                       </td>
                     </tr>
                   ))}
                 </tbody>
               </table>
            </div>
          </div>
        )}

        {activeTab === 'staff' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
            <h2 className="text-3xl font-black text-white mb-6">إدارة الموظفين والمدراء العامين</h2>
            <form onSubmit={addStaff} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] mb-8 flex gap-4 shadow-xl`}>
               <input name="name" required placeholder="الاسم" className={`flex-1 ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} />
               <input name="phone" required placeholder="الهاتف" className={`w-40 ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} dir="ltr" />
               <input name="passcode" required placeholder="الرمز" className={`w-32 ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white outline-none`} dir="ltr" />
               <input type="hidden" name="role" value="super_admin" />
               <button type="submit" className="bg-emerald-600 text-white font-bold px-8 rounded-xl">إضافة مسؤول</button>
            </form>
            <div className="grid grid-cols-2 gap-6">
               {staffMembers.map(s => (
                  <div key={s.id} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] flex items-center justify-between shadow-lg`}>
                     <div className="flex items-center gap-4">
                        <div className="w-14 h-14 bg-emerald-500/10 text-emerald-400 rounded-2xl flex items-center justify-center font-black text-2xl">{s.name.charAt(0)}</div>
                        <div><h4 className="font-bold text-white text-lg">{s.name}</h4><p className="text-sm text-slate-500 font-sans">{s.phone}</p></div>
                     </div>
                     <div className="flex gap-2">
                        <button onClick={()=>openEditModal('staff', s)} className="p-3 bg-[#02050a] text-blue-400 rounded-xl"><Edit3 size={18}/></button>
                     </div>
                  </div>
               ))}
            </div>
          </div>
        )}

        {activeTab === 'banners' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">شبكة الإعلانات</h2>
             <MediaUploader type="banner" />
             <div className="grid grid-cols-2 gap-6">
               {banners.map(b => (
                 <div key={b.id} className="relative rounded-3xl overflow-hidden border border-[#152033] h-48 bg-[#0a0f18] group">
                    <img src={b.url} className="w-full h-full object-cover opacity-60" />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#02050a] to-transparent p-6 flex flex-col justify-end"><h4 className="font-bold text-white text-xl">{b.title}</h4></div>
                    <button onClick={()=>deleteItem('banners', b.id)} className="absolute top-4 left-4 bg-red-500 p-2 rounded-xl opacity-0 group-hover:opacity-100 transition"><Trash2 size={18}/></button>
                 </div>
               ))}
             </div>
          </div>
        )}
        
        {activeTab === 'store' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">المتجر المركزي</h2>
             <MediaUploader type="store" />
             <div className="grid grid-cols-4 gap-4">
               {storeItems.map(s => (
                 <div key={s.id} className={`${theme.bgCard} border ${theme.border} rounded-2xl overflow-hidden`}>
                    <img src={s.url} className="w-full h-32 object-cover opacity-80" />
                    <div className="p-4 flex flex-col">
                       <h4 className="font-bold text-white text-sm mb-1">{s.title}</h4>
                       <p className="text-blue-400 font-bold font-sans text-xs">{s.price} IQD</p>
                       <button onClick={()=>deleteItem('store_items', s.id)} className="mt-4 text-red-400 bg-red-500/10 text-xs py-2 rounded-lg">حذف المنتج</button>
                    </div>
                 </div>
               ))}
             </div>
          </div>
        )}

        {activeTab === 'music' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">راديو المنظومة</h2>
             <MediaUploader type="music" />
             <div className="space-y-4">
               {musicTracks.map(m => (
                 <div key={m.id} className={`${theme.bgCard} border ${theme.border} p-4 rounded-2xl flex items-center justify-between`}>
                    <div className="flex items-center gap-4"><div className="w-12 h-12 bg-purple-500/20 text-purple-400 rounded-xl flex items-center justify-center"><Headphones size={20}/></div><h4 className="font-bold text-white text-lg">{m.title}</h4></div>
                    <div className="flex items-center gap-4"><audio src={m.url} controls className="h-10 custom-audio" /><button onClick={()=>deleteItem('music_tracks', m.id)} className="text-red-400 p-2"><Trash2 size={18}/></button></div>
                 </div>
               ))}
             </div>
          </div>
        )}

        {activeTab === 'tickets' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">تذاكر الدعم الفني</h2>
             <div className="space-y-4">
               {tickets.length===0 && <div className={`p-10 text-center ${theme.bgCard} border ${theme.border} rounded-3xl text-slate-500 font-bold`}>لا توجد تذاكر مفتوحة.</div>}
               {tickets.map(t => (
                  <div key={t.id} className={`${theme.bgCard} border ${theme.border} p-6 rounded-3xl`}>
                     <div className="flex justify-between items-start mb-4">
                        <div><h4 className="font-bold text-white text-lg">المرسل: {t.senderName}</h4><p className="text-sm text-slate-400 font-bold">القاعة: {t.gymName}</p></div>
                        <span className={`px-3 py-1 rounded-lg text-xs font-bold ${t.status==='open'?'bg-red-500/10 text-red-400':'bg-emerald-500/10 text-emerald-400'}`}>{t.status==='open'?'مفتوحة':'مغلقة'}</span>
                     </div>
                     <div className="bg-[#02050a] p-4 rounded-xl border-[#152033] text-slate-300 mb-4">{t.message}</div>
                     {t.status==='open' && <button onClick={async()=>{ await updateDoc(doc(db,'artifacts',appId,'public','data','support_tickets',t.id),{status:'closed'}); logAudit('إغلاق تذكرة', `إغلاق تذكرة ${t.gymName}`); showToast('تم الإغلاق'); }} className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold">إغلاق (تم الحل)</button>}
                  </div>
               ))}
             </div>
          </div>
        )}

        {activeTab === 'audit' && (
          <div className="animate-fade-in max-w-6xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">سجل الحركات الأمني (Audit Log)</h2>
             <div className={`${theme.bgCard} border ${theme.border} rounded-[2rem] overflow-hidden`}>
                <table className="w-full text-right">
                   <thead className="bg-[#02050a] text-slate-400 text-sm"><tr><th className="p-4">التاريخ والوقت</th><th className="p-4">الموظف/المدير</th><th className="p-4">الإجراء</th><th className="p-4">التفاصيل</th></tr></thead>
                   <tbody>
                      {auditLogs.map(a => (
                         <tr key={a.id} className="border-t border-[#152033] hover:bg-[#152033]/30">
                            <td className="p-4 text-xs text-slate-400 font-sans" dir="ltr">{new Date(a.timestamp).toLocaleString()}</td>
                            <td className="p-4 font-bold text-white">{a.userName}</td>
                            <td className="p-4"><span className="bg-blue-500/10 text-blue-400 px-2 py-1 rounded-lg text-xs font-bold">{a.action}</span></td>
                            <td className="p-4 text-sm text-slate-300">{a.details}</td>
                         </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        )}
      </div>
    </div>
  );
}

function GymAdmin({ profile, logout, theme, showToast, logAudit }) {
  const [activeTab, setActiveTab] = useState('radar');
  const [checkins, setCheckins] = useState([]);
  const [members, setMembers] = useState([]);
  const [storeOrders, setStoreOrders] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [memberTab, setMemberTab] = useState('plan'); 
  const [dietText, setDietText] = useState('');
  const [calories, setCalories] = useState('');
  const [pinInput, setPinInput] = useState('');
  const [chatMsgs, setChatMsgs] = useState([]);
  const [replyMsg, setReplyMsg] = useState('');
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [ticketMsg, setTicketMsg] = useState('');
  
  const [prevMsgCount, setPrevMsgCount] = useState(0);
  const [prevOrderCount, setPrevOrderCount] = useState(0);

  const [expenses, setExpenses] = useState([]);
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');

  useEffect(() => {
    if(!profile?.gymId) return;
    const unsubRadar = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'checkins'), snap => { let d=[]; snap.forEach(x=>{if(x.data().gymId===profile.gymId)d.push({id:x.id,...x.data()})}); d.sort((a,b)=>new Date(b.timestamp)-new Date(a.timestamp)); setCheckins(d); });
    const unsubMembers = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'profiles'), snap => { let d=[]; snap.forEach(x=>{if(x.data().gymId===profile.gymId && x.data().role==='user')d.push({id:x.id,...x.data()})}); setMembers(d); });
    
    const unsubOrders = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'store_orders'), snap => { 
      let d=[]; snap.forEach(x=>{if(x.data().gymId===profile.gymId)d.push({id:x.id,...x.data()})}); 
      if (d.length > prevOrderCount && prevOrderCount !== 0) showToast('يوجد طلب جديد من المتجر', 'info');
      setPrevOrderCount(d.length); setStoreOrders(d); 
    });
    
    const unsubChats = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'chats'), snap => { 
      let arr=[]; snap.forEach(d=>{ if(d.data().gymId === profile.gymId) arr.push({id:d.id, ...d.data()}) }); 
      arr.sort((a,b)=>new Date(a.timestamp)-new Date(b.timestamp)); 
      if (arr.length > prevMsgCount && prevMsgCount !== 0) {
        const lastMsg = arr[arr.length-1];
        if (lastMsg.sender === 'user') showToast(`رسالة جديدة من ${lastMsg.userName}`, 'info');
      }
      setPrevMsgCount(arr.length); setChatMsgs(arr); 
    });

    const unsubExp = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'expenses'), snap => {
      let e=[]; snap.forEach(x=>{if(x.data().gymId===profile.gymId)e.push({id:x.id,...x.data()})}); setExpenses(e);
    });

    return () => { unsubRadar(); unsubMembers(); unsubOrders(); unsubChats(); unsubExp(); };
  }, [profile, prevMsgCount, prevOrderCount]);

  const handlePinCheckin = async (e) => {
     e.preventDefault(); const m = members.find(x => x.checkinPin === pinInput);
     if(!m) return showToast('الكود غير صحيح', 'error');
     try {
       await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'checkins'), { userId: m.id, userName: m.name, gymId: profile.gymId, timestamp: new Date().toISOString() });
       logAudit('حضور يدوي بـ PIN', `تسجيل حضور ${m.name}`);
       showToast(`تم حضور ${m.name}`); setPinInput('');
     } catch(e){}
  };

  const savePlan = async () => {
    try {
      await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', selectedMember.id), { dietPlan: dietText, calories: calories });
      setSelectedMember({...selectedMember, dietPlan: dietText, calories: calories});
      logAudit('تحديث تغذية', `تحديث بيانات ${selectedMember.name}`);
      showToast('تم الحفظ لملف اللاعب');
    } catch(e) {}
  };

  const addWorkout = async (e) => {
    e.preventDefault(); const title = e.target.wTitle.value; if(!title) return;
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'workouts'), { userId: selectedMember.id, title, date: new Date().toISOString() });
    logAudit('إضافة تمرين', `تعيين تمرين لـ ${selectedMember.name}`);
    e.target.reset(); showToast('تم تعيين التمرين');
  };

  const renewSub = async (months) => {
    const baseDate = new Date(selectedMember.subscriptionEndsAt) < new Date() ? new Date() : new Date(selectedMember.subscriptionEndsAt);
    const newDate = new Date(baseDate.getTime() + (months * 30 * 24 * 60 * 60 * 1000));
    await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', selectedMember.id), { subscriptionEndsAt: newDate.toISOString() });
    setSelectedMember({...selectedMember, subscriptionEndsAt: newDate.toISOString()});
    logAudit('تجديد اشتراك', `تجديد ${months} شهر للاعب ${selectedMember.name}`);
    showToast(`تم التجديد`);
  };

  const sendBroadcast = async (e) => {
    e.preventDefault(); if(!broadcastMsg) return;
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'announcements'), { gymId: profile.gymId, message: broadcastMsg, date: new Date().toISOString() });
    setBroadcastMsg(''); showToast('تم إرسال التعميم للاعبين');
  };
  
  const sendTicket = async (e) => {
     e.preventDefault(); if(!ticketMsg) return;
     await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'support_tickets'), { gymId: profile.gymId, gymName: profile.gymName, senderName: profile.name, message: ticketMsg, status: 'open', timestamp: new Date().toISOString() });
     setTicketMsg(''); showToast('تم الإرسال للإدارة العليا');
  }

  const sendReply = async (e) => {
     e.preventDefault(); if(!replyMsg || !selectedMember) return;
     await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'chats'), { gymId: profile.gymId, userId: selectedMember.id, userName: 'الكابتن', message: replyMsg, sender: 'admin', timestamp: new Date().toISOString() });
     setReplyMsg('');
  };

  const handleAddExpense = async (e) => {
    e.preventDefault();
    if(!expenseDesc || !expenseAmount) return;
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'expenses'), {
      gymId: profile.gymId, desc: expenseDesc, amount: Number(expenseAmount), date: new Date().toISOString()
    });
    setExpenseDesc(''); setExpenseAmount(''); showToast('تم تسجيل المصروف');
  };

  const isOnline = (userId) => {
     const today = new Date().toDateString();
     return checkins.some(c => c.userId === userId && new Date(c.timestamp).toDateString() === today);
  };

  const totalRevenue = members.length * 50000; 
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const netProfit = totalRevenue - totalExpenses;

  return (
    <div className={`flex h-screen overflow-hidden ${theme.bgMain}`}>
      <div className={`w-72 ${theme.bgCard} border-l ${theme.border} flex flex-col z-20 shadow-2xl`}>
        <div className={`p-8 border-b ${theme.border}`}>
          <Activity size={40} className="text-blue-500 mb-4" />
          <h1 className="text-2xl font-black text-white leading-tight">{profile.gymName}</h1>
          <p className="text-sm font-bold text-blue-400 mt-1">كابتن {profile.name.split(' ')[0]}</p>
        </div>
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
          <SidebarBtn icon={<Radio/>} label="الرادار الحي" active={activeTab==='radar'} onClick={()=>setActiveTab('radar')} badge={checkins.length} color="blue" />
          <SidebarBtn icon={<Users/>} label="ملفات المتدربين" active={activeTab==='members'} onClick={()=>{setActiveTab('members'); setSelectedMember(null);}} color="blue" />
          <SidebarBtn icon={<ShoppingCart/>} label="طلبات المتجر" active={activeTab==='orders'} onClick={()=>setActiveTab('orders')} badge={storeOrders.filter(o=>o.status==='pending').length} color="blue" />
          <SidebarBtn icon={<MessageSquare/>} label="محادثات الكابتن" active={activeTab==='inbox'} onClick={()=>setActiveTab('inbox')} color="blue" />
          <SidebarBtn icon={<Megaphone/>} label="إشعارات القاعة" active={activeTab==='broadcast'} onClick={()=>setActiveTab('broadcast')} color="blue" />
          <SidebarBtn icon={<Receipt/>} label="المالية والمصروفات" active={activeTab==='finance'} onClick={()=>setActiveTab('finance')} color="emerald" />
          <SidebarBtn icon={<ShieldAlert/>} label="تواصل مع الإدارة" active={activeTab==='support'} onClick={()=>setActiveTab('support')} color="purple" />
          
          <div className="mt-8 pt-6 border-t border-[#152033]">
            <p className="text-xs text-slate-500 mb-3 font-bold">تسجيل حضور عبر PIN</p>
            <form onSubmit={handlePinCheckin} className="flex gap-2">
               <input value={pinInput} onChange={e=>setPinInput(e.target.value)} placeholder="رقم PIN" maxLength={4} className={`flex-1 ${theme.inputBg} border ${theme.border} rounded-xl p-3 outline-none text-white text-center font-sans tracking-widest font-black text-lg`} />
               <button type="submit" className="bg-blue-600 hover:bg-blue-500 transition text-white px-5 rounded-xl font-bold"><CheckCircle2 size={20}/></button>
            </form>
          </div>
        </nav>
        <div className={`p-4 border-t ${theme.border}`}>
          <button onClick={logout} className="w-full text-slate-400 hover:text-red-400 bg-[#02050a] p-4 rounded-2xl font-bold flex justify-center items-center gap-2"><LogOut size={20}/> تسجيل خروج</button>
        </div>
      </div>

      <div className="flex-1 p-10 overflow-y-auto relative bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#0f172a] via-[#02050a] to-[#02050a]">
        
        {activeTab === 'radar' && (
          <div className="animate-fade-in h-full flex flex-col max-w-6xl mx-auto">
            <h2 className="text-4xl font-black text-white mb-8 flex items-center gap-4">الرادار المباشر <span className="bg-red-500/10 text-red-500 text-sm px-4 py-1.5 rounded-full flex items-center gap-2 border border-red-500/30 animate-pulse font-bold tracking-widest"><span className="w-2.5 h-2.5 bg-red-500 rounded-full"></span> LIVE</span></h2>
            <div className={`flex-1 ${theme.bgCard} border ${theme.border} rounded-[3rem] p-6 relative overflow-hidden shadow-2xl flex items-center justify-center`}>
               <div className="w-[600px] h-[600px] border border-blue-900/30 rounded-full animate-[ping_6s_ease-out_infinite] absolute"></div>
               <div className="w-[400px] h-[400px] border border-[#1a253a] rounded-full absolute"></div>
               <div className="w-[300px] h-[300px] border border-[#1a253a] rounded-full absolute"></div>
               <div className="absolute w-24 h-24 bg-[#02050a] border-[4px] border-blue-500 rounded-full flex items-center justify-center z-10 shadow-[0_0_50px_rgba(59,130,246,0.6)]">
                 <Radio size={40} className="text-blue-400 animate-pulse" />
               </div>
               <div className="relative z-20 w-full h-full">
                 {checkins.length === 0 && <div className="absolute inset-0 flex items-center justify-center text-slate-500 font-bold bg-[#02050a]/80 backdrop-blur-md rounded-[2.5rem] m-8 border border-[#1a253a]">بانتظار إدخال الـ PIN...</div>}
                 {checkins.map((c, i) => {
                   const t = 20 + ((i * 47) % 60) + '%'; const r = 20 + ((i * 61) % 60) + '%';
                   return (
                   <div key={c.id} className="absolute flex flex-col items-center animate-bounce z-20" style={{top: t, right: r}}>
                     <div className="w-6 h-6 bg-emerald-500 rounded-full shadow-[0_0_20px_rgba(16,185,129,1)] border-[3px] border-[#02050a]"></div>
                     <span className="text-xs bg-[#02050a]/90 px-3 py-1 rounded-lg border border-slate-700 mt-2 font-bold text-white shadow-xl backdrop-blur-md">{c.userName}</span>
                   </div>
                 )})}
               </div>
            </div>
          </div>
        )}

        {activeTab === 'members' && !selectedMember && (
          <div className="animate-fade-in max-w-6xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-8">ملفات المشتركين ({members.length})</h2>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {members.map(m => {
                   const days = Math.ceil((new Date(m.subscriptionEndsAt) - new Date()) / (1000 * 60 * 60 * 24));
                   const online = isOnline(m.id);
                   return(
                  <div key={m.id} onClick={()=>{setSelectedMember(m); setDietText(m.dietPlan||''); setCalories(m.calories||''); setMemberTab('plan');}} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] transition shadow-lg cursor-pointer hover:border-blue-500/50 group relative`}>
                    <div className="absolute top-6 left-6">
                       {online ? <div className="flex items-center gap-1 text-xs text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg"><span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> بالصالة</div> : <div className="text-xs text-slate-500">غائب</div>}
                    </div>
                    <div className="flex items-center gap-4 mb-4">
                      {m.avatarUrl ? <img src={m.avatarUrl} className="w-16 h-16 rounded-[1.5rem] object-cover border border-[#152033] group-hover:scale-105 transition" /> : <div className="w-16 h-16 bg-[#02050a] text-blue-500 rounded-[1.5rem] border border-[#152033] flex items-center justify-center font-black text-3xl group-hover:scale-105 transition">{m.name.charAt(0)}</div>}
                      <div><h3 className="font-bold text-white text-xl">{m.name}</h3><p className={`text-sm ${theme.textMuted} font-sans font-bold mt-1`} dir="ltr">{m.phone}</p></div>
                    </div>
                    <div className="bg-[#02050a] p-3 rounded-xl border border-[#152033] flex justify-between items-center">
                       <span className="text-xs font-bold text-slate-400">PIN: <span className="text-emerald-400 font-sans tracking-widest ml-1">{m.checkinPin}</span></span>
                       <span className={`text-xs font-black px-2 py-1 rounded ${days<=0?'bg-red-500/20 text-red-400':'bg-emerald-500/20 text-emerald-400'}`}>{days<=0?'منتهي':`باقي ${days} يوم`}</span>
                    </div>
                  </div>
                )})}
             </div>
          </div>
        )}

        {activeTab === 'members' && selectedMember && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <button onClick={()=>setSelectedMember(null)} className="text-slate-400 hover:text-white flex items-center gap-2 mb-6 font-bold bg-[#0a0f18] px-4 py-2 rounded-xl border border-[#152033]"><ChevronRight/> عودة</button>
             
             <div className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2.5rem] shadow-2xl mb-6 flex flex-col md:flex-row items-center justify-between gap-6`}>
                 <div className="flex items-center gap-6">
                    {selectedMember.avatarUrl ? <img src={selectedMember.avatarUrl} className="w-24 h-24 rounded-[2rem] object-cover border-2 border-blue-500" /> : <div className="w-24 h-24 bg-blue-500/10 text-blue-500 rounded-[2rem] flex items-center justify-center font-black text-5xl border border-blue-500/20">{selectedMember.name.charAt(0)}</div>}
                    <div>
                      <h2 className="text-4xl font-black text-white mb-2">{selectedMember.name}</h2>
                      <div className="flex gap-3 text-sm font-bold text-slate-400 bg-[#02050a] p-2 rounded-xl border border-[#152033]">
                         <span className="px-2 border-l border-slate-700">عمر: {selectedMember.age}</span><span className="px-2 border-l border-slate-700">وزن: {selectedMember.weight}kg</span><span className="px-2 font-sans tracking-widest text-emerald-400">PIN: {selectedMember.checkinPin}</span>
                      </div>
                    </div>
                 </div>
                 <div className="flex bg-[#02050a] p-2 rounded-2xl border border-[#152033]">
                    <button onClick={()=>setMemberTab('plan')} className={`px-6 py-2.5 rounded-xl font-bold transition ${memberTab==='plan'?'bg-blue-600 text-white':'text-slate-400 hover:text-white'}`}>الخطة والتمارين</button>
                    <button onClick={()=>setMemberTab('sub')} className={`px-6 py-2.5 rounded-xl font-bold transition ${memberTab==='sub'?'bg-blue-600 text-white':'text-slate-400 hover:text-white'}`}>الاشتراك</button>
                 </div>
             </div>

             {memberTab === 'plan' && (
                <div className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2.5rem] shadow-xl animate-fade-in`}>
                   <h3 className="font-bold text-2xl text-white mb-6 flex items-center gap-3"><Flame className="text-orange-500"/> التغذية والتمارين</h3>
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                     <div><label className="block text-sm font-bold text-slate-400 mb-2">السعرات اليومية</label><input type="number" value={calories} onChange={e=>setCalories(e.target.value)} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white font-sans text-2xl font-black outline-none`} /></div>
                     <div><label className="block text-sm font-bold text-slate-400 mb-2">الجدول الغذائي</label><textarea value={dietText} onChange={e=>setDietText(e.target.value)} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white min-h-[150px] outline-none leading-loose`}></textarea></div>
                   </div>
                   <button onClick={savePlan} className="w-full bg-blue-600 text-white font-black py-4 rounded-xl flex justify-center items-center gap-2 mb-8 shadow-lg"><CheckCircle2 size={22}/> حفظ وتحديث تطبيق اللاعب</button>
                   <div className="border-t border-[#152033] pt-8">
                      <h3 className="font-bold text-xl text-white mb-4 flex items-center gap-2"><Dumbbell className="text-blue-500"/> تعيين تمرين جديد</h3>
                      <form onSubmit={addWorkout} className="flex gap-4">
                        <input name="wTitle" required placeholder="مثال: صدر + بايسيبس" className={`flex-1 ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white font-bold outline-none focus:border-blue-500`} />
                        <button type="submit" className="bg-blue-600 text-white px-8 py-4 rounded-xl font-bold flex items-center gap-2"><Plus size={20}/> إضافة للتطبيق</button>
                      </form>
                   </div>
                </div>
             )}
             {memberTab === 'sub' && (
                <div className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2.5rem] shadow-xl animate-fade-in`}>
                   <h3 className="font-bold text-2xl text-white mb-6 flex items-center gap-3"><CreditCard className="text-emerald-500"/> إدارة الاشتراك</h3>
                   <div className="bg-[#02050a] p-6 rounded-2xl border border-[#152033] mb-8 flex justify-between items-center">
                      <span className="text-slate-400 font-bold text-lg">تاريخ الانتهاء:</span><span className="text-2xl font-black text-white font-sans" dir="ltr">{new Date(selectedMember.subscriptionEndsAt).toLocaleDateString()}</span>
                   </div>
                   <button onClick={()=>renewSub(1)} className="w-full bg-emerald-600 text-white py-4 rounded-xl font-black text-lg flex justify-center items-center gap-2"><Calendar size={22}/> تجديد شهر كامل</button>
                </div>
             )}
          </div>
        )}

        {activeTab === 'finance' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-8">المالية وتجديد الاشتراكات</h2>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
               <div className="bg-emerald-900/20 border border-emerald-500/30 p-8 rounded-[2rem] shadow-xl">
                  <h3 className="text-lg font-bold text-emerald-400 mb-2">الإيرادات التقديرية (الشهر الحالي)</h3>
                  <p className="text-4xl font-black text-white font-sans">{totalRevenue.toLocaleString()} <span className="text-xl text-slate-400">IQD</span></p>
               </div>
               <div className="bg-red-900/20 border border-red-500/30 p-8 rounded-[2rem] shadow-xl">
                  <h3 className="text-lg font-bold text-red-400 mb-2">إجمالي المصروفات</h3>
                  <p className="text-4xl font-black text-white font-sans">{totalExpenses.toLocaleString()} <span className="text-xl text-slate-400">IQD</span></p>
               </div>
             </div>
             
             <div className="bg-blue-900/20 border border-blue-500/30 p-8 rounded-[2rem] shadow-xl mb-10 text-center">
                <h3 className="text-xl font-bold text-blue-400 mb-2">صافي الربح التقديري</h3>
                <p className="text-5xl font-black text-white font-sans">{netProfit.toLocaleString()} <span className="text-2xl text-slate-400">IQD</span></p>
             </div>

             <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-bold text-xl text-white mb-6">تسجيل مصروفات</h3>
                  <form onSubmit={handleAddExpense} className={`${theme.bgCard} border ${theme.border} p-6 rounded-3xl`}>
                     <input value={expenseDesc} onChange={e=>setExpenseDesc(e.target.value)} required placeholder="وصف المصروف (مثال: تنظيف, صيانة)" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white mb-4 outline-none`} />
                     <input value={expenseAmount} onChange={e=>setExpenseAmount(e.target.value)} required type="number" placeholder="المبلغ (IQD)" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-4 text-white mb-4 outline-none font-sans`} />
                     <button type="submit" className="w-full bg-red-600/80 text-white font-bold py-4 rounded-xl">تسجيل خصم</button>
                  </form>
                </div>
                <div>
                  <h3 className="font-bold text-xl text-white mb-6">الاشتراكات المنتهية والقريبة</h3>
                  <div className="space-y-4 max-h-[400px] overflow-y-auto custom-scrollbar pr-2">
                    {members.filter(m => Math.ceil((new Date(m.subscriptionEndsAt) - new Date()) / (1000 * 60 * 60 * 24)) <= 5).length===0 && <p className="text-slate-500">لا يوجد اشتراكات قريبة.</p>}
                    {members.filter(m => Math.ceil((new Date(m.subscriptionEndsAt) - new Date()) / (1000 * 60 * 60 * 24)) <= 5).map(m => {
                      const days = Math.ceil((new Date(m.subscriptionEndsAt) - new Date()) / (1000 * 60 * 60 * 24));
                      return (
                      <div key={m.id} className={`${theme.bgCard} border ${days<=0?'border-red-500/50':'border-[#152033]'} p-5 rounded-3xl flex flex-col gap-4 shadow-lg`}>
                        <div className="flex justify-between items-center">
                          <div><h4 className="font-bold text-lg text-white">{m.name}</h4><p className={`text-sm font-bold mt-1 ${days<=0?'text-red-400':'text-yellow-500'}`}>{days<=0?'منتهي الصلاحية':`ينتهي بعد ${days} أيام`}</p></div>
                          <div className="text-emerald-400 font-sans tracking-widest font-black text-lg bg-[#02050a] px-3 py-1 rounded-xl border border-[#152033]">{m.checkinPin}</div>
                        </div>
                        <button onClick={()=>{setSelectedMember(m); setActiveTab('members'); setMemberTab('sub');}} className="w-full bg-[#02050a] border border-[#152033] text-white py-3 rounded-xl font-black transition hover:bg-emerald-600 hover:border-emerald-500">تجديد العضوية</button>
                      </div>
                    )})}
                  </div>
                </div>
             </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="animate-fade-in max-w-5xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">طلبات المتجر الواردة من اللاعبين</h2>
             {storeOrders.length===0 && <div className={`p-10 text-center ${theme.bgCard} border border-[#152033] rounded-3xl text-slate-500 font-bold`}>لا يوجد طلبات حالياً.</div>}
             <div className="space-y-4">
                {storeOrders.map(o => (
                  <div key={o.id} className={`${theme.bgCard} border border-[#152033] p-6 rounded-3xl flex flex-col md:flex-row justify-between items-center shadow-lg gap-4`}>
                     <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2"><span className="bg-blue-500/20 text-blue-400 px-3 py-1 rounded-lg text-sm font-bold">{o.locationZone}</span></div>
                        <h4 className="font-bold text-lg text-white">{o.userName} طلب: <span className="text-blue-400">{o.productName}</span></h4>
                        <p className="text-emerald-400 font-bold font-sans my-1">{o.price} IQD <span className="text-slate-500 text-xs ml-2">(الدفع: {o.paymentMethod==='cash'?'نقدي':'نقاط'})</span></p>
                        {o.userNotes && <p className="text-sm text-slate-300 bg-[#02050a] p-3 rounded-xl border border-[#152033] mt-2">ملاحظة: {o.userNotes}</p>}
                     </div>
                     {o.status === 'pending' ? (
                       <button onClick={async()=>{ await updateDoc(doc(db,'artifacts',appId,'public','data','store_orders',o.id), {status:'delivered'}); showToast('تم تسليم الطلب');}} className="bg-emerald-600 text-white px-8 py-4 rounded-xl font-bold flex items-center gap-2 w-full md:w-auto justify-center"><CheckCircle2 size={20}/> تأكيد التسليم</button>
                     ) : (
                       <span className="bg-emerald-500/10 text-emerald-400 px-6 py-4 rounded-xl font-bold flex items-center gap-2"><CheckCircle2 size={20}/> تم التسليم</span>
                     )}
                  </div>
                ))}
             </div>
          </div>
        )}

        {activeTab === 'broadcast' && (
          <div className="animate-fade-in max-w-4xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">الإذاعة الداخلية (للاعبين)</h2>
             <form onSubmit={sendBroadcast} className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2.5rem] shadow-xl`}>
               <textarea value={broadcastMsg} onChange={e=>setBroadcastMsg(e.target.value)} required placeholder="اكتب إعلان يظهر في هواتف اللاعبين..." className={`w-full ${theme.inputBg} border ${theme.border} rounded-2xl p-6 outline-none min-h-[180px] mb-6 text-white text-lg`}></textarea>
               <button type="submit" className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 text-lg"><Megaphone size={22}/> إرسال الإشعار للجميع</button>
             </form>
          </div>
        )}

        {activeTab === 'inbox' && (
           <div className="animate-fade-in max-w-6xl mx-auto flex flex-col md:flex-row h-[75vh] gap-6">
              <div className={`w-full md:w-1/3 ${theme.bgCard} border ${theme.border} rounded-[2.5rem] overflow-hidden flex flex-col`}>
                 <div className="p-6 border-b border-[#152033] font-black text-xl text-white">المحادثات</div>
                 <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1">
                    {members.map(m => (
                       <div key={m.id} onClick={()=>setSelectedMember(m)} className={`p-4 rounded-2xl cursor-pointer transition flex items-center gap-4 ${selectedMember?.id===m.id?'bg-[#02050a] border border-blue-500/30 text-white':'text-slate-400 hover:bg-[#02050a]'}`}>
                          {m.avatarUrl ? <img src={m.avatarUrl} className="w-12 h-12 rounded-xl object-cover" /> : <div className="w-12 h-12 bg-blue-500/10 text-blue-500 rounded-xl flex items-center justify-center font-bold text-lg">{m.name.charAt(0)}</div>}
                          <div className="font-bold">{m.name}</div>
                       </div>
                    ))}
                 </div>
              </div>
              <div className={`flex-1 ${theme.bgCard} border ${theme.border} rounded-[2.5rem] flex flex-col overflow-hidden`}>
                 {selectedMember ? (
                   <>
                     <div className="p-6 border-b border-[#152033] flex items-center gap-4">
                        {selectedMember.avatarUrl ? <img src={selectedMember.avatarUrl} className="w-12 h-12 rounded-xl object-cover" /> : <div className="w-12 h-12 bg-blue-500/10 text-blue-500 rounded-xl flex items-center justify-center font-bold text-xl">{selectedMember.name.charAt(0)}</div>}
                        <h3 className="font-black text-xl text-white">{selectedMember.name}</h3>
                     </div>
                     <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar flex flex-col">
                        {chatMsgs.filter(m=>m.userId === selectedMember.id).map(msg => (
                           <div key={msg.id} className={`max-w-[75%] p-4 rounded-2xl text-sm font-bold ${msg.sender==='admin'?'bg-blue-600 text-white self-start rounded-tr-none':'bg-[#02050a] border border-[#152033] text-slate-300 self-end rounded-tl-none'}`}><p>{msg.message}</p></div>
                        ))}
                     </div>
                     <form onSubmit={sendReply} className="p-4 border-t border-[#152033] flex gap-3 bg-[#02050a]">
                        <input value={replyMsg} onChange={e=>setReplyMsg(e.target.value)} placeholder="رد الكابتن..." className={`flex-1 bg-[#0a0f18] border ${theme.border} rounded-xl p-4 text-white outline-none`} />
                        <button type="submit" className="bg-blue-600 text-white w-14 rounded-xl flex items-center justify-center"><Send size={20}/></button>
                     </form>
                   </>
                 ) : ( <div className="flex-1 flex flex-col items-center justify-center text-slate-500 font-bold"><MessageSquare size={48} className="mb-4 opacity-20"/> اختر لاعباً للرد عليه</div> )}
              </div>
           </div>
        )}

        {activeTab === 'support' && (
          <div className="animate-fade-in max-w-4xl mx-auto">
             <h2 className="text-3xl font-black text-white mb-6">تواصل مع الإدارة العليا</h2>
             <form onSubmit={sendTicket} className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2.5rem] shadow-xl`}>
               <textarea value={ticketMsg} onChange={e=>setTicketMsg(e.target.value)} required placeholder="اكتب رسالتك هنا..." className={`w-full ${theme.inputBg} border ${theme.border} rounded-2xl p-6 outline-none min-h-[180px] mb-6 text-white text-lg`}></textarea>
               <button type="submit" className="w-full bg-purple-600 text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 text-lg"><Send size={22}/> إرسال التذكرة</button>
             </form>
          </div>
        )}

      </div>
    </div>
  );
}

function UserApp({ profile, user, logout, theme, showToast }) {
  const [activeTab, setActiveTab] = useState('home'); 
  const [liveProfile, setLiveProfile] = useState(profile);
  
  const [workouts, setWorkouts] = useState([]);
  const [storeItems, setStoreItems] = useState([]);
  const [chatMsgs, setChatMsgs] = useState([]);
  const [replyMsg, setReplyMsg] = useState('');
  const [banners, setBanners] = useState([]);
  const [music, setMusic] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [checkoutProduct, setCheckoutProduct] = useState(null);
  const [profileImg, setProfileImg] = useState(profile?.avatarUrl || null);
  
  // New Features States
  const [waterCups, setWaterCups] = useState(profile?.waterIntake || 0);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);

  useEffect(() => {
    if(!user || !profile) return;
    
    // Live Profile Listener
    const unsubProfile = onSnapshot(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', profile.id), doc => {
       if(doc.exists()) {
          const d = doc.data();
          setLiveProfile({id: doc.id, ...d});
          if (d.avatarUrl && d.avatarUrl !== profileImg) setProfileImg(d.avatarUrl);
          if (d.waterIntake !== undefined) setWaterCups(d.waterIntake);
       }
    });

    const uW = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'workouts'), s => { let arr=[]; s.forEach(d=>{if(d.data().userId===profile.id)arr.push({id:d.id, ...d.data()})}); setWorkouts(arr); });
    const uS = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'store_items'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setStoreItems(arr); });
    const uB = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'banners'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setBanners(arr); });
    const uM = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'music_tracks'), s => { let arr=[]; s.forEach(d=>arr.push({id:d.id,...d.data()})); setMusic(arr); });
    const uA = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'announcements'), s => { let arr=[]; s.forEach(d=>{if(d.data().gymId===profile.gymId)arr.push({id:d.id,...d.data()})}); arr.sort((a,b)=>new Date(b.date)-new Date(a.date)); setAnnouncements(arr); });
    const uC = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'chats'), s => { 
      let arr=[]; s.forEach(d=>{if(d.data().userId===profile.id)arr.push({id:d.id,...d.data()})}); 
      arr.sort((a,b)=>new Date(a.timestamp)-new Date(b.timestamp)); 
      setChatMsgs(arr); 
    });
    
    return () => { unsubProfile(); uW(); uS(); uB(); uM(); uA(); uC(); };
  }, [user, profile]);

  useEffect(() => {
    let interval;
    if (timerRunning) interval = setInterval(() => setTimerSeconds(s => s + 1), 1000);
    else clearInterval(interval);
    return () => clearInterval(interval);
  }, [timerRunning]);

  const addWater = async () => {
    const newCount = waterCups + 1;
    setWaterCups(newCount);
    try { await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', liveProfile.id), { waterIntake: newCount }); } catch(e){}
  };

  const handleCheckout = async (e) => {
     e.preventDefault(); const fd = new FormData(e.target);
     try {
        await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'store_orders'), { 
          userId: liveProfile.id, userName: liveProfile.name, gymId: liveProfile.gymId, productId: checkoutProduct.id, productName: checkoutProduct.title, price: checkoutProduct.price, locationZone: fd.get('locationZone'), paymentMethod: fd.get('paymentMethod'), userNotes: fd.get('notes'), status: 'pending', timestamp: new Date().toISOString() 
        });
        setCheckoutProduct(null); showToast('تم إرسال طلبك للكابتن');
     } catch(e) { showToast('خطأ في الطلب', 'error'); }
  }

  const sendMsg = async (e) => {
     e.preventDefault(); if(!replyMsg) return;
     try { await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'chats'), { gymId: liveProfile.gymId, userId: liveProfile.id, userName: liveProfile.name, message: replyMsg, sender: 'user', timestamp: new Date().toISOString() }); setReplyMsg(''); } catch (e) {}
  };

  const updateProfileSettings = async (e) => {
    e.preventDefault(); const fd = new FormData(e.target); let updates = {};
    if (fd.get('weight')) updates.weight = fd.get('weight');
    if (fd.get('height')) updates.height = fd.get('height');
    if (fd.get('passcode') && fd.get('passcode').length >= 4) updates.passcode = fd.get('passcode');
    
    const file = e.target.avatarInput?.files[0];
    if (file) {
      if (file.size > 800000) return showToast('حجم الصورة كبير جداً (Max 800KB)', 'error');
      try { const base64Img = await fileToBase64(file); updates.avatarUrl = base64Img; setProfileImg(base64Img); } catch (err) { return showToast('فشل قراءة الصورة', 'error'); }
    }
    try {
      await updateDoc(doc(db, 'artifacts', appId, 'public', 'data', 'profiles', liveProfile.id), updates);
      showToast('تم تحديث البيانات');
      setActiveTab('home');
    } catch (err) {}
  };

  const daysLeft = liveProfile ? Math.ceil((new Date(liveProfile.subscriptionEndsAt) - new Date()) / (1000 * 60 * 60 * 24)) : 0;
  const isExpired = daysLeft <= 0;

  const formatTime = (secs) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="min-h-screen bg-[#020408] flex items-center justify-center p-4 relative sm:bg-[url('https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80')] sm:bg-cover sm:bg-center">
      <div className="absolute inset-0 bg-[#02050a]/95 hidden sm:block backdrop-blur-xl"></div>
      
      {checkoutProduct && (
         <div className="absolute inset-0 bg-[#02050a]/90 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-fade-in sm:w-[420px] sm:mx-auto">
            <form onSubmit={handleCheckout} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] w-full shadow-2xl`}>
               <h3 className="text-xl font-black text-white mb-4">إتمام الطلب</h3>
               <div className="bg-[#020408] p-4 rounded-xl border border-[#152033] mb-4 flex items-center gap-4">
                  <img src={checkoutProduct.url} className="w-14 h-14 rounded-xl object-cover" />
                  <div><div className="font-bold text-white">{checkoutProduct.title}</div><div className="text-emerald-400 font-sans font-bold">{checkoutProduct.price} IQD</div></div>
               </div>
               <div className="space-y-3 mb-6">
                 <div><select name="locationZone" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3 outline-none text-white font-bold`}><option value="الاستقبال">الاستقبال</option><option value="قسم الحديد">قسم الحديد</option><option value="قسم الكارديو">قسم الكارديو</option></select></div>
                 <div><select name="paymentMethod" required className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3 outline-none text-white font-bold`}><option value="cash">نقداً للكابتن</option></select></div>
                 <div><textarea name="notes" placeholder="ملاحظات للكابتن (مثال: قريب من البنش برس)" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3 outline-none text-white min-h-[80px] text-sm`}></textarea></div>
               </div>
               <div className="flex gap-3"><button type="submit" className="flex-1 bg-emerald-600 text-white font-bold py-4 rounded-xl shadow-lg">تأكيد الطلب</button><button type="button" onClick={()=>setCheckoutProduct(null)} className="bg-[#020408] text-slate-400 border border-[#152033] px-6 rounded-xl font-bold">إلغاء</button></div>
            </form>
         </div>
      )}

      <div className="w-full h-full sm:w-[420px] sm:h-[880px] bg-[#020408] sm:border-[8px] border-[#152033] sm:rounded-[3.5rem] overflow-hidden relative shadow-[0_0_60px_rgba(0,0,0,0.9)] flex flex-col z-10">
        
        <header className="px-6 pt-16 pb-6 flex justify-between items-center bg-[#0a0f18] relative z-10 border-b border-[#152033]">
          <div className="flex items-center gap-4">
            <div className="relative cursor-pointer" onClick={() => setActiveTab('settings')}>
               {profileImg ? (
                 <img src={profileImg} className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.3)]" alt="Profile" />
               ) : (
                 <div className="w-14 h-14 bg-emerald-500/10 border-2 border-emerald-500 text-emerald-400 rounded-2xl flex items-center justify-center font-black text-2xl shadow-[0_0_15px_rgba(16,185,129,0.3)]">{liveProfile?.name.charAt(0)}</div>
               )}
               <div className="absolute -bottom-1 -right-1 bg-emerald-500 rounded-full p-1 border-2 border-[#0a0f18]"><Settings2 size={12} className="text-slate-900"/></div>
            </div>
            <div>
               <h2 className="text-white font-black text-xl">أهلاً يا بطل!</h2>
               <div className="flex items-center gap-2 mt-1"><span className="text-emerald-400 text-[10px] font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">{liveProfile?.gymName}</span></div>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={()=>setActiveTab('timer')} className={`w-10 h-10 rounded-full ${activeTab==='timer'?'bg-emerald-600 text-white':'bg-[#020408] border border-[#152033] text-slate-400 hover:text-white'} flex justify-center items-center transition`}><Timer size={16}/></button>
            <button onClick={logout} className="w-10 h-10 rounded-full bg-[#020408] border border-[#152033] flex justify-center items-center text-red-400"><LogOut size={16}/></button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-5 space-y-6 pb-28 hide-scrollbar">
          
          {activeTab === 'home' && (
            <div className="animate-fade-in space-y-5">
              
              {announcements.length>0 && (
                <div className="bg-blue-500/10 border border-blue-500/30 p-4 rounded-2xl flex gap-3 items-start"><MessageSquare className="text-blue-500" size={20}/><div><h4 className="text-sm text-blue-400 font-bold mb-1">إشعار القاعة</h4><p className="text-xs text-white leading-relaxed">{announcements[0].message}</p></div></div>
              )}
              {banners.slice(0,1).map((b,i)=>(
                 <div key={i} className="rounded-3xl overflow-hidden relative h-32 border border-[#152033]"><img src={b.url} className="w-full h-full object-cover opacity-80"/><div className="absolute inset-0 bg-gradient-to-t from-[#020408] p-4 flex flex-col justify-end"><h4 className="font-bold text-white">{b.title}</h4></div></div>
              ))}

              <div className={`p-8 rounded-[2.5rem] text-center shadow-2xl relative overflow-hidden ${isExpired ? 'bg-red-950/20 border border-red-500/30' : 'bg-gradient-to-br from-[#0a0f18] to-[#020408] border border-[#152033]'}`}>
                  <div className="absolute -top-10 -right-10 text-slate-800/50"><QrCode size={120} /></div>
                  <div className="relative z-10">
                     <h3 className="text-slate-400 font-bold mb-2">كود الدخول للقاعة (PIN)</h3>
                     <div className={`text-6xl font-black font-sans tracking-[0.2em] mb-4 flex justify-center items-center gap-4 ${isExpired?'text-red-500':'text-emerald-400 drop-shadow-[0_0_20px_rgba(16,185,129,0.5)]'}`}>
                       {liveProfile?.checkinPin}
                     </div>
                     <p className="text-xs text-slate-400 font-bold">أعط هذا الكود للكابتن لتسجيل حضورك.</p>
                  </div>
              </div>

              <div className="flex gap-4">
                <div className={`flex-1 ${theme.bgCard} border ${isExpired?'border-red-500':'border-[#152033]'} rounded-[2rem] p-5 text-center`}><span className={`text-3xl font-black font-sans ${isExpired?'text-red-500':'text-white'}`}>{daysLeft<0?0:daysLeft}</span><span className="text-[10px] font-bold text-slate-400 block mt-1">يوم متبقي</span></div>
                <div className={`flex-1 bg-[#020408] border border-[#152033] rounded-[2rem] p-5 text-center`}><span className="text-2xl font-black text-blue-400 font-sans block">{liveProfile?.weight || '--'}</span><span className="text-[10px] font-bold text-slate-400 block mt-1">الوزن (Kg)</span></div>
                <div onClick={addWater} className={`flex-1 bg-[#020408] border border-blue-500/30 rounded-[2rem] p-5 text-center cursor-pointer hover:bg-blue-900/20 transition`}><Droplets size={24} className="mx-auto text-blue-400 mb-1"/><span className="text-xl font-black text-white font-sans block">{waterCups}</span><span className="text-[10px] font-bold text-blue-400 block mt-1">+ شربت</span></div>
              </div>

            </div>
          )}

          {activeTab === 'plan' && (
            <div className="animate-fade-in space-y-6">
               <h3 className="text-3xl font-black text-white px-2">خطتي (Plan)</h3>
               
               {/* Calories Target */}
               <div className="bg-gradient-to-br from-orange-900/40 to-[#0a0f18] border border-orange-500/30 p-8 rounded-[2.5rem] shadow-xl text-center">
                  <Flame size={48} className="mx-auto text-orange-500 mb-4 drop-shadow-[0_0_15px_rgba(249,115,22,0.6)]" />
                  <p className="text-slate-300 font-bold mb-2">السعرات المستهدفة (يومياً)</p>
                  <div className="text-5xl font-black text-white font-sans">{liveProfile?.calories || '0'} <span className="text-xl text-orange-500">Kcal</span></div>
               </div>
               
               {/* Diet Plan */}
               <div className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2.5rem] shadow-xl`}>
                  <h4 className="font-bold text-xl text-white mb-6 border-b border-[#152033] pb-4 flex items-center gap-2"><ImageIcon size={20} className="text-emerald-500" /> النظام الغذائي</h4>
                  {liveProfile?.dietPlan ? (
                    <div className="text-slate-300 font-bold leading-loose whitespace-pre-wrap">{liveProfile.dietPlan}</div>
                  ) : (
                    <div className="text-center text-slate-500 py-4 font-bold">بانتظار إضافة الجدول من الكابتن.</div>
                  )}
               </div>

               {/* Workouts */}
               <div className={`${theme.bgCard} border ${theme.border} p-8 rounded-[2.5rem] shadow-xl`}>
                  <h4 className="font-bold text-xl text-white mb-6 border-b border-[#152033] pb-4 flex items-center gap-2"><DumbbellIcon size={20} className="text-blue-500" /> التمارين المعينة</h4>
                  {workouts.length === 0 ? (
                    <div className="text-center text-slate-500 py-4 font-bold">بانتظار تعيين التمارين.</div>
                  ) : (
                    <div className="space-y-4">
                      {workouts.map(w => (
                         <div key={w.id} className="bg-[#020408] border border-[#152033] p-5 rounded-[1.5rem] flex items-center gap-4">
                            <div className="w-12 h-12 bg-blue-500/10 text-blue-500 rounded-xl flex items-center justify-center"><Play size={20} fill="currentColor"/></div>
                            <h4 className="font-bold text-white text-lg flex-1">{w.title}</h4>
                         </div>
                      ))}
                    </div>
                  )}
               </div>
            </div>
          )}

          {activeTab === 'market' && (
             <div className="animate-fade-in space-y-6">
                  <h3 className="text-3xl font-black text-white mb-4 mt-2 px-2">متجر القاعة</h3>
                  {storeItems.length === 0 && <div className="p-10 text-center bg-[#0a0f18] rounded-3xl border border-[#152033] text-slate-500 font-bold">لا توجد منتجات معروضة حالياً.</div>}
                  <div className="grid grid-cols-2 gap-4">
                     {storeItems.map((p, i) => (
                       <div key={i} className={`${theme.bgCard} border ${theme.border} rounded-3xl overflow-hidden flex flex-col shadow-lg`}>
                          <img src={p.url} className="w-full h-28 object-cover opacity-80" alt={p.title} />
                          <div className="p-4 flex-1 flex flex-col">
                            <h4 className="font-bold text-white text-sm mb-1">{p.title}</h4>
                            <p className="text-emerald-400 font-bold font-sans text-xs mb-3">{p.price} IQD</p>
                            <button onClick={()=>setCheckoutProduct(p)} className="mt-auto bg-blue-600 text-white text-xs font-bold py-3 rounded-xl w-full active:scale-95 transition">طلب للمكان</button>
                          </div>
                       </div>
                     ))}
                  </div>
             </div>
          )}

          {activeTab === 'radio' && (
             <div className="animate-fade-in space-y-6">
               <h3 className="text-3xl font-black text-white mb-4 px-2 flex items-center gap-3"><Headphones className="text-purple-500"/> راديو القاعة</h3>
               {music.length === 0 && <div className={`p-10 text-center ${theme.bgCard} rounded-[2rem] border ${theme.border} text-slate-500 font-bold`}>المكتبة الصوتية فارغة حالياً.</div>}
               {music.map((m, i) => (
                  <div key={i} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2.5rem] text-center shadow-lg`}>
                     <div className="w-20 h-20 bg-purple-500/10 text-purple-400 rounded-full flex items-center justify-center mx-auto mb-4 border border-purple-500/20"><Music size={32}/></div>
                     <h4 className="font-bold text-white text-lg mb-6">{m.title}</h4>
                     <audio src={m.url} controls className="w-full custom-audio" />
                  </div>
               ))}
             </div>
          )}

          {activeTab === 'chat' && (
             <div className="animate-fade-in flex flex-col h-[70vh]">
               <h3 className="text-2xl font-black text-white mb-4 px-2">تواصل مع الكابتن</h3>
               <div className={`flex-1 ${theme.bgCard} border ${theme.border} rounded-[2rem] flex flex-col overflow-hidden shadow-xl`}>
                  <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar flex flex-col">
                     {chatMsgs.length === 0 && <div className="text-center text-slate-500 mt-10 font-bold">أرسل استفسارك الآن. سيقوم الكابتن بالرد عليك قريباً.</div>}
                     {chatMsgs.map(msg => (
                        <div key={msg.id} className={`max-w-[85%] p-3.5 rounded-2xl text-sm font-bold ${msg.sender==='user'?'bg-emerald-600 text-white self-end rounded-tl-none':'bg-[#020408] border border-[#152033] text-slate-200 self-start rounded-tr-none'}`}>
                          <p>{msg.message}</p>
                          <span className="text-[10px] opacity-50 block mt-1" dir="ltr">{new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        </div>
                     ))}
                  </div>
                  <form onSubmit={sendMsg} className="p-3 border-t border-[#152033] flex gap-2 bg-[#020408]">
                     <input value={replyMsg} onChange={e=>setReplyMsg(e.target.value)} placeholder="اكتب سؤالك للكابتن..." className={`flex-1 bg-[#0a0f18] border ${theme.border} rounded-xl p-3 text-white outline-none text-sm`} />
                     <button type="submit" className="bg-emerald-600 text-white w-12 rounded-xl flex justify-center items-center active:scale-95 transition"><Send size={18}/></button>
                  </form>
               </div>
             </div>
          )}

          {activeTab === 'timer' && (
             <div className="animate-fade-in space-y-6 flex flex-col items-center justify-center h-[60vh]">
                  <Timer size={64} className="text-emerald-500 mb-4 drop-shadow-[0_0_20px_rgba(16,185,129,0.5)]"/>
                  <h3 className="text-3xl font-black text-white mb-2">مؤقت التمرين</h3>
                  <div className="text-7xl font-black font-sans text-white tracking-widest">{formatTime(timerSeconds)}</div>
                  <div className="flex gap-4 mt-8 w-full px-8">
                     <button onClick={()=>setTimerRunning(!timerRunning)} className={`flex-1 ${timerRunning?'bg-red-500/10 text-red-500 border border-red-500/30':'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'} py-4 rounded-2xl font-black text-lg transition`}>{timerRunning ? 'إيقاف' : 'بدء'}</button>
                     <button onClick={()=>{setTimerRunning(false); setTimerSeconds(0);}} className="bg-[#0a0f18] text-slate-400 border border-[#152033] px-6 rounded-2xl font-bold">تصفير</button>
                  </div>
             </div>
          )}

          {activeTab === 'settings' && (
             <div className="animate-fade-in space-y-6">
                <h3 className="text-2xl font-black text-white mb-6">إعدادات ملفي</h3>
                <form onSubmit={updateProfileSettings} className={`${theme.bgCard} border ${theme.border} p-6 rounded-[2rem] shadow-xl`}>
                   <div className="flex flex-col items-center mb-8 border-b border-[#152033] pb-6">
                     <div className="relative mb-4">
                        {profileImg ? <img src={profileImg} className="w-24 h-24 rounded-[1.5rem] object-cover border-2 border-emerald-500" /> : <div className="w-24 h-24 bg-emerald-500/10 text-emerald-500 rounded-[1.5rem] flex items-center justify-center font-black text-4xl border border-emerald-500/30">{liveProfile?.name.charAt(0)}</div>}
                        <label className="absolute -bottom-2 -right-2 bg-emerald-600 text-white p-2 rounded-xl cursor-pointer hover:bg-emerald-500 transition shadow-lg"><Edit3 size={16} /><input type="file" name="avatarInput" accept="image/*" className="hidden" /></label>
                     </div>
                     <p className="text-sm text-slate-400 font-bold">تغيير الصورة الشخصية</p>
                   </div>
                   <div className="space-y-4 mb-6">
                     <div><label className="block text-xs font-bold text-slate-400 mb-1">الوزن (Kg)</label><input type="number" name="weight" defaultValue={liveProfile?.weight} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3 outline-none text-white`} /></div>
                     <div><label className="block text-xs font-bold text-slate-400 mb-1">الطول (Cm)</label><input type="number" name="height" defaultValue={liveProfile?.height} className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3 outline-none text-white`} /></div>
                     <div className="pt-4 border-t border-[#152033]"><label className="block text-xs font-bold text-slate-400 mb-1">تغيير الرمز السري الجديد (PIN)</label><input type="text" name="passcode" placeholder="اتركه فارغاً إذا لم ترد تغييره" className={`w-full ${theme.inputBg} border ${theme.border} rounded-xl p-3 outline-none text-white tracking-widest font-sans`} /></div>
                   </div>
                   <button type="submit" className="w-full bg-emerald-600 text-white font-bold py-4 rounded-xl flex justify-center items-center gap-2 active:scale-95 transition shadow-lg">حفظ التغييرات</button>
                </form>
             </div>
          )}

        </div>

        <div className="absolute bottom-0 inset-x-0 bg-[#0a0f18] border-t border-[#152033] h-20 flex justify-around items-center px-2 pb-2 z-50 rounded-b-[3.5rem] sm:rounded-b-[2.5rem]">
           <button onClick={()=>setActiveTab('home')} className={`flex flex-col items-center transition-all ${activeTab==='home'?'text-emerald-400 scale-110':'text-slate-500'}`}><div className={`p-2 rounded-2xl mb-1 ${activeTab==='home'?'bg-emerald-500/20 border border-emerald-500/30':''}`}><Activity size={22}/></div><span className="text-[10px] font-bold">الرئيسية</span></button>
           <button onClick={()=>setActiveTab('plan')} className={`flex flex-col items-center transition-all ${activeTab==='plan'?'text-orange-400 scale-110':'text-slate-500'}`}><div className={`p-2 rounded-2xl mb-1 ${activeTab==='plan'?'bg-orange-500/20 border border-orange-500/30':''}`}><Flame size={22}/></div><span className="text-[10px] font-bold">خطتي</span></button>
           <button onClick={()=>setActiveTab('market')} className={`flex flex-col items-center transition-all ${activeTab==='market'?'text-blue-400 scale-110':'text-slate-500'}`}><div className={`p-2 rounded-2xl mb-1 ${activeTab==='market'?'bg-blue-500/20 border border-blue-500/30':''}`}><ShoppingBag size={22}/></div><span className="text-[10px] font-bold">المتجر</span></button>
           <button onClick={()=>setActiveTab('radio')} className={`flex flex-col items-center transition-all ${activeTab==='radio'?'text-purple-400 scale-110':'text-slate-500'}`}><div className={`p-2 rounded-2xl mb-1 ${activeTab==='radio'?'bg-purple-500/20 border border-purple-500/30':''}`}><Headphones size={22}/></div><span className="text-[10px] font-bold">الراديو</span></button>
           <button onClick={()=>setActiveTab('chat')} className={`flex flex-col items-center transition-all ${activeTab==='chat'?'text-emerald-400 scale-110':'text-slate-500'}`}><div className={`p-2 rounded-2xl mb-1 ${activeTab==='chat'?'bg-emerald-500/20 border border-emerald-500/30':''}`}><MessageSquare size={22}/></div><span className="text-[10px] font-bold">الكابتن</span></button>
        </div>
      </div>
    </div>
  );
}

// Shared Component
function SidebarBtn({ icon, label, active, onClick, badge, color='emerald' }) {
  const colorMap = { emerald: 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30', blue: 'bg-blue-500/10 text-blue-400 border border-blue-500/30', purple: 'bg-purple-500/10 text-purple-400 border border-purple-500/30', gold: 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/30' };
  return (
    <div onClick={onClick} className={`p-4 rounded-2xl flex items-center justify-between cursor-pointer transition font-bold ${active ? colorMap[color] : 'text-slate-400 hover:bg-[#152033]'}`}>
      <div className="flex items-center gap-4">{icon} <span className="text-[15px]">{label}</span></div>
      {badge > 0 && <span className="bg-red-500 text-white text-xs px-2.5 py-0.5 rounded-full shadow-lg">{badge}</span>}
    </div>
  );
}

function StatCard({ icon, title, value, color='emerald' }) {
  const colors = { emerald: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20', blue: 'text-blue-500 bg-blue-500/10 border-blue-500/20', purple: 'text-purple-500 bg-purple-500/10 border-purple-500/20', gold: 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20' };
  return (
    <div className={`bg-[#0a0f18] border border-[#152033] p-8 rounded-[2.5rem] shadow-lg flex flex-col`}>
      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border mb-6 shadow-inner ${colors[color]}`}>{React.cloneElement(icon, { size: 28 })}</div>
      <h3 className="text-5xl font-black text-white font-sans tracking-tight mb-2">{value}</h3>
      <p className="text-sm font-bold text-slate-400">{title}</p>
    </div>
  );
}