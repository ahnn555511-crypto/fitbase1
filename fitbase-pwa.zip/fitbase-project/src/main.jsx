import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import InstallPrompt from './InstallPrompt.jsx';

createRoot(document.getElementById('root')).render(
  <>
    <App />
    <InstallPrompt />
  </>
);

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch((err) => console.error('SW error:', err));
  });
}
