# FitBase ERP — خطوات النشر

## 1) إنشاء مشروع Firebase (مرة واحدة)
1. ادخل https://console.firebase.google.com وأنشئ مشروعاً جديداً.
2. من Build > Authentication > Sign-in method فعّل **Anonymous**.
3. من Build > Firestore Database أنشئ قاعدة بيانات، ثم من تبويب Rules الصق محتوى ملف `firestore.rules` واضغط Publish.
4. من Project settings > Your apps أضف تطبيق **Web** (</>) وانسخ قيم الإعدادات (apiKey وغيرها).

## 2) ضبط المفاتيح
انسخ `.env.example` إلى ملف باسم `.env` واملأ القيم التي نسختها.

## 3) التشغيل على جهازك
```
npm install
npm run dev
```

## 4) النشر
**Vercel (الأسهل):** ارفع المجلد إلى GitHub، ثم في Vercel اختر Import Project، وأضف نفس متغيرات `.env` في Settings > Environment Variables، ثم Deploy.

**Netlify:** نفس الفكرة: Build command = `npm run build` و Publish directory = `dist`، وأضف المتغيرات.

**Firebase Hosting:** `npm i -g firebase-tools` ثم `firebase login` ثم `firebase init hosting` (اختر dist وSPA = yes) ثم `npm run build` ثم `firebase deploy`.

## ملاحظات
- الكود في `src/App.jsx` هو كودك الأصلي، وتغيّرت فيه الأسطر الخاصة بإعدادات Firebase فقط (من السطر 17 إلى 26).
- كلمة سر المدير العام الافتراضية في الكود هي 0000 (هاتف 0000). غيّرها فوراً بعد أول دخول.
- الرموز السرية للأعضاء مخزنة كنص عادي في قاعدة البيانات، وقواعد Firestore أعلاه تسمح لأي مستخدم مجهول بالقراءة والكتابة. هذا مناسب للتجربة فقط، وقبل استخدام بيانات عملاء حقيقيين يلزم نظام دخول وقواعد أمان أقوى.
- Tailwind محمّل من CDN لتبسيط الإعداد، وهو يعمل لكنه ليس الأمثل للإنتاج.

## التثبيت كتطبيق (PWA)
المشروع هسه جاهز للتثبيت من المتصفح بعد النشر على رابط **HTTPS** (Vercel/Netlify/Firebase كلها HTTPS تلقائياً):
- **أندرويد (Chrome):** يظهر شريط "ثبّت FitBase" أسفل الشاشة، أو القائمة ⋮ > تثبيت التطبيق.
- **آيفون/آيباد (Safari فقط):** زر المشاركة > إضافة إلى الشاشة الرئيسية. (آبل ما تسمح بنافذة تثبيت تلقائية.)
- **سطح المكتب (Chrome/Edge):** أيقونة التثبيت بشريط العنوان، أو يظهر شريط التثبيت بالصفحة.
- الملفات: `public/manifest.webmanifest` و`public/sw.js` و`public/icons/` و`src/InstallPrompt.jsx`.
- عند تحديث التطبيق وتغيير الملفات القديمة، غيّر رقم `CACHE` بأول `public/sw.js` (مثلاً fitbase-v2).
- لتغيير الأيقونة: بدّل الصور بـ `public/icons/` بنفس الأسماء والأحجام.
